# WiiXNative Android — base experimental

Projeto Android arm64 baseado no código original fornecido. Inclui interface, biblioteca de jogos, editor de controles de toque, ponte JNI, código C++ inicial, parser/carregador experimental de RPX e uma tela de diagnóstico.

## Gerar APK pelo GitHub
1. Crie um repositório vazio no GitHub.
2. Envie **todo o conteúdo desta pasta** (`WiiUEmuAndroid`) para a raiz do repositório — incluindo `app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties` e `.github/`.
3. Abra a aba **Actions** e execute `WiiXNative Android APK` (ou faça push para `main`).
4. Quando terminar, abra a execução e baixe o artefato `WiiXNative-Android-debug`.
5. Extraia o ZIP do artefato e instale `app-debug.apk` em um aparelho Android 10+ ARM64.

## Recursos existentes nesta base
- Controles virtuais editáveis, analógicos, botões e perfis.
- Biblioteca que reconhece diretórios de jogos `code/content/meta` e arquivos comuns.
- Preferência de escala por jogo de 0,10X a 1,00X e preferência Vulkan/OpenGL ES armazenadas por jogo.
- Código nativo C++/JNI, relatório Vulkan e parser ELF/RPX experimental.

## Limitações reais (não confundir interface com emulação pronta)
- O backend gráfico Wii U GX2 → Vulkan/OpenGL ES ainda não existe. As opções de escala/renderizador são preferências; não reduzem ainda a resolução de um jogo renderizado.
- O interpretador PowerPC é parcial e não implementa Cafe OS, bibliotecas de sistema, GPU Latte, áudio e demais serviços necessários para jogos comerciais.
- `.WUD`, `.WUX`, `.WUA` e `.WUHb` ainda não são carregados; exigem suporte de formato, descriptografia e/ou descompressão.
- Jogos RPX podem ser reconhecidos e submetidos ao núcleo experimental, mas isso não significa que inicializem como um jogo Wii U completo.
- Drivers Vulkan personalizados de terceiros não são carregados por esta versão. Android normalmente restringe a substituição do driver do sistema; uma lista/instalador visual não faria isso funcionar.

Use apenas dumps e chaves de jogos/sistema que você tenha direito de utilizar.
