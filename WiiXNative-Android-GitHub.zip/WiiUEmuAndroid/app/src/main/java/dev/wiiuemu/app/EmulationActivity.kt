package dev.wiiuemu.app

import android.app.AlertDialog
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs

/** Tela de jogo: vídeo do núcleo + controles na tela + controle físico + giroscópio. */
class EmulationActivity : ComponentActivity(), OnScreenControlsView.Listener, SensorEventListener, SurfaceHolder.Callback {

    private lateinit var controls: OnScreenControlsView
    private lateinit var statusView: TextView
    private lateinit var cfg: ControlConfig
    private lateinit var settings: GameSettings
    private val ui = Handler(Looper.getMainLooper())
    private var userPaused = false
    private var started = false

    // entrada: tela, controle físico e giroscópio são combinados em push()
    private var osB = 0; private var osLx = 0f; private var osLy = 0f; private var osRx = 0f; private var osRy = 0f
    private var keyB = 0; private var hatB = 0; private var trigB = 0
    private var pLx = 0f; private var pLy = 0f; private var pRx = 0f; private var pRy = 0f
    private var gyroRx = 0f; private var gyroRy = 0f
    private var touching = false; private var tx = 0f; private var ty = 0f

    private val poll = object : Runnable {
        override fun run() {
            if (EmulatorBridge.loaded && settings.diagHud) statusView.text = EmulatorBridge.nativeStatus()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val key = intent.getStringExtra("key") ?: "x"
        val name = intent.getStringExtra("name") ?: "Jogo"
        settings = Store.settings(this, key)
        cfg = Store.controls(this, key)
        requestedOrientation = if (settings.orientation == 0) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val sv = SurfaceView(this).also { it.holder.addCallback(this) }
        controls = OnScreenControlsView(this, cfg).also { it.listener = this }
        statusView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; setBackgroundColor(Color.parseColor("#80000000"))
            setPadding(Ui.dp(this@EmulationActivity, 8), Ui.dp(this@EmulationActivity, 4), Ui.dp(this@EmulationActivity, 8), Ui.dp(this@EmulationActivity, 4))
            text = name; visibility = if (settings.diagHud) android.view.View.VISIBLE else android.view.View.GONE
        }
        val menu = TextView(this).apply {
            text = "☰"; setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#80000000"))
            setOnClickListener { showMenu() }
        }
        root.addView(sv, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(controls, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(statusView, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.START).apply { leftMargin = Ui.dp(this@EmulationActivity, 56) })
        root.addView(menu, FrameLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 36), Gravity.TOP or Gravity.END).apply { topMargin = Ui.dp(this@EmulationActivity, 4); rightMargin = Ui.dp(this@EmulationActivity, 4) })
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() { showMenu() } })
        startCore(name)
    }

    private fun startCore(name: String) {
        if (!EmulatorBridge.loaded) { statusView.visibility = android.view.View.VISIBLE; statusView.text = "Biblioteca nativa não carregada."; return }
        val uri = Uri.parse(intent.getStringExtra("uri") ?: return)
        val isFolder = intent.getBooleanExtra("folder", false)
        val ext = if (isFolder) "rpx" else (intent.getStringExtra("ext") ?: "")
        statusView.text = "Carregando $name..."
        Thread {
            val src: Uri? = if (isFolder) GameScanner.findMainRpx(this, uri) else uri
            val fd = try { if (src != null) contentResolver.openFileDescriptor(src, "r")?.detachFd() ?: -1 else -1 } catch (e: Exception) { -1 }
            val msg = if (src == null) "ERRO: não achei nenhum .rpx na pasta code/ deste jogo."
                      else EmulatorBridge.nativeStart(fd, ext, name, settings.toNative())
            runOnUiThread {
                started = msg.startsWith("OK")
                if (!started) { statusView.visibility = android.view.View.VISIBLE; statusView.text = msg }
                else ui.post(poll)
            }
        }.start()
    }

    // ---------- menu ----------
    private fun showMenu() {
        val items = arrayOf(if (userPaused) "Retomar" else "Pausar", if (cfg.showControls) "Ocultar controles" else "Mostrar controles", "Sair do jogo")
        AlertDialog.Builder(this).setItems(items) { _, which ->
            when (which) {
                0 -> { userPaused = !userPaused; if (EmulatorBridge.loaded) EmulatorBridge.nativePause(userPaused) }
                1 -> { cfg.showControls = !cfg.showControls; controls.invalidate() }
                2 -> finish()
            }
        }.show()
    }

    // ---------- superfície ----------
    override fun surfaceCreated(h: SurfaceHolder) { if (EmulatorBridge.loaded) EmulatorBridge.nativeEmuSurface(h.surface) }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { if (EmulatorBridge.loaded) EmulatorBridge.nativeEmuSurface(null) }

    // ---------- ciclo de vida ----------
    override fun onResume() {
        super.onResume()
        if (EmulatorBridge.loaded && started) EmulatorBridge.nativePause(userPaused)
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }
    override fun onPause() {
        super.onPause()
        if (EmulatorBridge.loaded) EmulatorBridge.nativePause(true)
        (getSystemService(Context.SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }
    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        if (EmulatorBridge.loaded) EmulatorBridge.nativeStop()
        super.onDestroy()
    }

    // ---------- entrada: tela ----------
    override fun onInput(buttons: Int, lx: Float, ly: Float, rx: Float, ry: Float, touch: Boolean, tx: Float, ty: Float) {
        osB = buttons; osLx = lx; osLy = ly; osRx = rx; osRy = ry
        touching = touch; this.tx = tx; this.ty = ty
        if (EmulatorBridge.loaded) EmulatorBridge.nativeSetTouch(touch, tx, ty)
        push()
    }

    private fun push() {
        if (!EmulatorBridge.loaded) return
        fun c(v: Float) = v.coerceIn(-1f, 1f)
        val gx = if (cfg.gyroAim) gyroRx else 0f; val gy = if (cfg.gyroAim) gyroRy else 0f
        EmulatorBridge.nativeSetInput(osB or keyB or hatB or trigB, c(osLx + pLx), c(osLy + pLy), c(osRx + pRx + gx), c(osRy + pRy + gy))
    }

    // ---------- entrada: controle físico ----------
    private fun mapKey(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_BUTTON_A -> Btn.B; KeyEvent.KEYCODE_BUTTON_B -> Btn.A
        KeyEvent.KEYCODE_BUTTON_X -> Btn.Y; KeyEvent.KEYCODE_BUTTON_Y -> Btn.X
        KeyEvent.KEYCODE_BUTTON_L1 -> Btn.L; KeyEvent.KEYCODE_BUTTON_R1 -> Btn.R
        KeyEvent.KEYCODE_BUTTON_L2 -> Btn.ZL; KeyEvent.KEYCODE_BUTTON_R2 -> Btn.ZR
        KeyEvent.KEYCODE_BUTTON_START -> Btn.PLUS; KeyEvent.KEYCODE_BUTTON_SELECT -> Btn.MINUS
        KeyEvent.KEYCODE_BUTTON_MODE -> Btn.HOME
        KeyEvent.KEYCODE_BUTTON_THUMBL -> Btn.L3; KeyEvent.KEYCODE_BUTTON_THUMBR -> Btn.R3
        KeyEvent.KEYCODE_DPAD_UP -> Btn.UP; KeyEvent.KEYCODE_DPAD_DOWN -> Btn.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Btn.LEFT; KeyEvent.KEYCODE_DPAD_RIGHT -> Btn.RIGHT
        else -> 0
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        val m = mapKey(keyCode)
        if (m != 0) { keyB = keyB or m; push(); return true }
        return super.onKeyDown(keyCode, event)
    }
    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        val m = mapKey(keyCode)
        if (m != 0) { keyB = keyB and m.inv(); push(); return true }
        return super.onKeyUp(keyCode, event)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if ((e.source and InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK || e.action != MotionEvent.ACTION_MOVE) return super.onGenericMotionEvent(e)
        fun dz(v: Float) = if (abs(v) < 0.1f) 0f else v
        pLx = dz(e.getAxisValue(MotionEvent.AXIS_X)); pLy = -dz(e.getAxisValue(MotionEvent.AXIS_Y))
        pRx = dz(e.getAxisValue(MotionEvent.AXIS_Z)); pRy = -dz(e.getAxisValue(MotionEvent.AXIS_RZ))
        val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X); val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        hatB = (if (hx < -0.5f) Btn.LEFT else 0) or (if (hx > 0.5f) Btn.RIGHT else 0) or (if (hy < -0.5f) Btn.UP else 0) or (if (hy > 0.5f) Btn.DOWN else 0)
        trigB = (if (e.getAxisValue(MotionEvent.AXIS_LTRIGGER) > 0.5f) Btn.ZL else 0) or (if (e.getAxisValue(MotionEvent.AXIS_RTRIGGER) > 0.5f) Btn.ZR else 0)
        push()
        return true
    }

    // ---------- giroscópio ----------
    override fun onSensorChanged(e: SensorEvent) {
        if (e.sensor.type != Sensor.TYPE_GYROSCOPE) return
        if (EmulatorBridge.loaded) EmulatorBridge.nativeSetGyro(e.values[0], e.values[1], e.values[2])
        if (cfg.gyroAim) {
            // Em paisagem o eixo X do aparelho é vertical na tela (guinada) e o Y é horizontal (inclinação).
            // Os sinais ainda precisam de calibração em aparelho real; ROTATION_270 inverte.
            @Suppress("DEPRECATION") val rot = windowManager.defaultDisplay.rotation
            val sign = if (rot == Surface.ROTATION_270) -1f else 1f
            gyroRx = (sign * e.values[0] * cfg.gyroSens / 2f).coerceIn(-1f, 1f)
            gyroRy = (-sign * e.values[1] * cfg.gyroSens / 2f).coerceIn(-1f, 1f)
            push()
        }
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
