package dev.wiiuemu.app

import android.view.Surface

/** Ponte JNI para o núcleo C++ do emulador. */
object EmulatorBridge {
    val loaded: Boolean = try { System.loadLibrary("wiiuemu"); true } catch (t: Throwable) { false }

    // tela principal (relatório Vulkan)
    external fun nativeSurfaceCreated(surface: Surface)
    external fun nativeSurfaceDestroyed()
    external fun nativeVulkanReport(): String
    external fun nativeLoadTitle(path: String): String

    // núcleo: ciclo de vida
    external fun nativeEmuSurface(surface: Surface?)
    /** fd: descritor do .rpx (o núcleo fecha). settings: "chave=valor;...". */
    external fun nativeStart(fd: Int, ext: String, name: String, settings: String): String
    external fun nativePause(paused: Boolean)
    external fun nativeStop()
    external fun nativeStatus(): String

    // núcleo: entrada (botões = máscara de Btn)
    external fun nativeSetInput(buttons: Int, lx: Float, ly: Float, rx: Float, ry: Float)
    external fun nativeSetTouch(down: Boolean, x: Float, y: Float)
    external fun nativeSetGyro(x: Float, y: Float, z: Float)
}
