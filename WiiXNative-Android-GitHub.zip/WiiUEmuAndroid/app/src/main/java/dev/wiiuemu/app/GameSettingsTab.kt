package dev.wiiuemu.app

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Aba "Config. jogos": opções salvas por jogo (resolução, FPS, áudio, idioma...). */
class GameSettingsTab(
    private val ctx: Context,
    private val games: () -> List<Game>,
    private val onEditControls: (Game) -> Unit
) {
    val root: View
    private val page = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, Ui.dp(ctx, 16)) }
    private val pickerBox = FrameLayout(ctx)
    private val formBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private var current: Game? = null

    init {
        page.addView(pickerBox); page.addView(formBox)
        root = ScrollView(ctx).apply { addView(page, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }
        rebuild()
    }

    fun refresh() { if (current != null && games().none { it.uri == current!!.uri }) current = null; rebuild() }
    fun select(g: Game) { current = g; rebuild() }

    private fun rebuild() {
        pickerBox.removeAllViews(); formBox.removeAllViews()
        val list = games()
        if (list.isEmpty()) {
            formBox.addView(TextView(ctx).apply { setTextColor(Ui.MUTED); textSize = 14f; setPadding(0, Ui.dp(ctx, 24), 0, 0)
                text = "Nenhum jogo na biblioteca. Escolha a pasta de jogos na aba Jogos." })
            return
        }
        if (current == null) current = list.first()
        val g = current!!
        val sel = list.indexOfFirst { it.uri == g.uri }.coerceAtLeast(0)
        pickerBox.addView(Ui.spinner(ctx, "Jogo", list.map { it.name }, sel) { pos -> current = games().getOrNull(pos); rebuild() })

        val key = Store.gameKey(g)
        val s = Store.settings(ctx, key)
        fun save() = Store.saveSettings(ctx, key, s)

        val card = Ui.card(ctx)
        card.addView(Ui.section(ctx, "GRÁFICOS"))
        val scales = listOf(0.10f, 0.15f, 0.20f, 0.25f, 0.30f, 0.40f, 0.50f, 0.60f, 0.70f, 0.75f, 0.80f, 0.90f, 1.00f)
        card.addView(Ui.spinner(ctx, "Escala de resolução (experimental)", scales.map { "%.2fX".format(java.util.Locale.US, it) }, scales.indexOfFirst { kotlin.math.abs(it - s.resScale) < 0.001f }.coerceAtLeast(0)) { s.resScale = scales[it]; save() })
        val renderers = listOf("Vulkan", "OpenGL ES")
        card.addView(Ui.spinner(ctx, "Renderizador preferido", renderers, renderers.indexOf(s.renderer).coerceAtLeast(0)) { s.renderer = renderers[it]; save() })
        card.addView(Ui.note(ctx, "A seleção é salva por jogo. O backend gráfico Wii U (GX2 → Vulkan/OpenGL ES) ainda não está implementado; trocar esta opção não ativa um renderizador de jogos."))
        card.addView(Ui.spinner(ctx, "Limite de FPS", listOf("30", "60", "Sem limite"), when (s.fps) { 30 -> 0; 0 -> 2; else -> 1 }) {
            s.fps = when (it) { 0 -> 30; 2 -> 0; else -> 60 }; save() })
        card.addView(Ui.switch(ctx, "VSync", s.vsync) { s.vsync = it; save() })
        card.addView(Ui.switch(ctx, "Cache de shaders", s.shaderCache) { s.shaderCache = it; save() })
        card.addView(Ui.section(ctx, "SISTEMA"))
        val langs = listOf("pt" to "Português", "en" to "English", "es" to "Español", "ja" to "日本語")
        card.addView(Ui.spinner(ctx, "Idioma do console", langs.map { it.second }, langs.indexOfFirst { it.first == s.language }.coerceAtLeast(0)) { s.language = langs[it].first; save() })
        card.addView(Ui.switch(ctx, "Áudio", s.audio) { s.audio = it; save() })
        card.addView(Ui.spinner(ctx, "Orientação", listOf("Paisagem", "Livre (sensor)"), s.orientation) { s.orientation = it; save() })
        card.addView(Ui.switch(ctx, "Painel de diagnóstico (entrada e estado da CPU)", s.diagHud) { s.diagHud = it; save() })
        formBox.addView(card, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = Ui.dp(ctx, 8) })

        formBox.addView(Ui.button(ctx, "Editar controles deste jogo", true).apply { setOnClickListener { onEditControls(g) } },
            LinearLayout.LayoutParams(MATCH_PARENT, Ui.dp(ctx, 48)).apply { topMargin = Ui.dp(ctx, 12) })
        formBox.addView(Ui.button(ctx, "Restaurar padrão").apply {
            setOnClickListener {
                AlertDialog.Builder(ctx).setTitle("Restaurar configurações de ${g.name}?")
                    .setPositiveButton("Restaurar") { _, _ -> Store.resetSettings(ctx, key); rebuild() }
                    .setNegativeButton("Cancelar", null).show()
            }
        }, LinearLayout.LayoutParams(MATCH_PARENT, Ui.dp(ctx, 48)).apply { topMargin = Ui.dp(ctx, 8) })
        formBox.addView(Ui.note(ctx, "Escala e renderizador são preferências salvas. A renderização real de jogos depende da implementação do backend gráfico Wii U; no momento a tela é de diagnóstico."),
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = Ui.dp(ctx, 10) })
    }
}
