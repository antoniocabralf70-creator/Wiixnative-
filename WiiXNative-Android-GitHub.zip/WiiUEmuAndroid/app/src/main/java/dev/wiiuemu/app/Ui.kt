package dev.wiiuemu.app

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

/** Pequenos construtores de interface (o app monta tudo em código, sem XML). */
object Ui {
    val BG = Color.parseColor("#0F1115")
    val CARD = Color.parseColor("#1A1D24")
    val ACCENT = Color.parseColor("#2D8CFF")
    val TEXT = Color.parseColor("#F2F4F8")
    val MUTED = Color.parseColor("#9AA3B2")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(c: Context, color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(c, r).toFloat() }

    fun button(c: Context, label: String, filled: Boolean = false) = Button(c).apply {
        text = label; isAllCaps = false; setTextColor(TEXT); textSize = 14f
        background = rounded(c, if (filled) ACCENT else CARD, 12); stateListAnimator = null
    }

    fun section(c: Context, text: String) = TextView(c).apply {
        this.text = text; setTextColor(ACCENT); textSize = 13f
        setPadding(0, dp(c, 16), 0, dp(c, 4))
    }

    fun note(c: Context, text: String) = TextView(c).apply { this.text = text; setTextColor(MUTED); textSize = 12f }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(c, CARD, 12); setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 10))
    }

    /** Slider com rótulo e valor. Os valores são inteiros em [min, max]. */
    fun seek(c: Context, label: String, lo: Int, hi: Int, value: Int, fmt: (Int) -> String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(c, 6), 0, 0) }
        val head = TextView(c).apply { setTextColor(TEXT); textSize = 14f; text = "$label: ${fmt(value)}" }
        val sb = SeekBar(c).apply {
            this.max = hi - lo; progress = value - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    head.text = "$label: ${fmt(p + lo)}"
                    if (fromUser) onChange(p + lo)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(head); box.addView(sb, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return box
    }

    fun switch(c: Context, label: String, value: Boolean, onChange: (Boolean) -> Unit): View = Switch(c).apply {
        text = label; setTextColor(TEXT); textSize = 14f; isChecked = value
        setPadding(0, dp(c, 8), 0, dp(c, 8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    fun spinner(c: Context, label: String?, options: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(c, 6), 0, dp(c, 2)) }
        if (label != null) box.addView(TextView(c).apply { setTextColor(TEXT); textSize = 14f; text = label })
        val sp = Spinner(c).apply {
            adapter = ArrayAdapter(c, android.R.layout.simple_spinner_item, options).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
            setSelection(selected.coerceIn(0, (options.size - 1).coerceAtLeast(0)), false)
            background = rounded(c, Color.parseColor("#262B36"), 8)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                var first = true
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { if (first) { first = false; if (pos == selected) return }; onSelect(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        box.addView(sp, LinearLayout.LayoutParams(MATCH_PARENT, dp(c, 44)))
        return box
    }
    fun center() = Gravity.CENTER
}
