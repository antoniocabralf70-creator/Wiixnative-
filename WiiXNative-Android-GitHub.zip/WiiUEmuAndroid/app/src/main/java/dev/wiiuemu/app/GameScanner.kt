package dev.wiiuemu.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document

data class Game(
    val name: String,
    val uri: Uri,
    val titleId: String?,
    val icon: Bitmap?,
    val isFolder: Boolean,
    val ext: String = ""
)

private class Node(val id: String, val name: String, val isDir: Boolean)

/**
 * Encontra jogos de dois jeitos:
 *  1) Pasta de jogo (formato do app de PC): contém "code", "content" e "meta".
 *     Nome e ícone vêm de meta/meta.xml e meta/iconTex.tga.
 *  2) Arquivos soltos: .wua .wud .wux .rpx .wuhb ...
 */
object GameScanner {
    private val EXT = setOf("wua", "wud", "wux", "rpx", "wuhb", "elf", "iso")

    fun scan(ctx: Context, tree: Uri, onProgress: (Int) -> Unit): List<Game> {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        val out = ArrayList<Game>()
        walk(ctx, tree, rootId, "", 0, out, onProgress)
        return out.sortedBy { it.name.lowercase() }
    }

    private fun walk(
        ctx: Context, tree: Uri, dirId: String, dirName: String, depth: Int,
        out: MutableList<Game>, onProgress: (Int) -> Unit
    ) {
        val kids = children(ctx, tree, dirId)
        val meta = kids.firstOrNull { it.isDir && it.name.equals("meta", true) }
        val code = kids.firstOrNull { it.isDir && it.name.equals("code", true) }
        if (meta != null && code != null) {
            out += readGame(ctx, tree, dirId, dirName, meta.id)
            onProgress(out.size)
            return
        }
        for (k in kids) {
            if (k.isDir) {
                if (depth < 6) walk(ctx, tree, k.id, k.name, depth + 1, out, onProgress)
            } else if (k.name.substringAfterLast('.', "").lowercase() in EXT) {
                out += Game(
                    k.name.substringBeforeLast('.'),
                    DocumentsContract.buildDocumentUriUsingTree(tree, k.id),
                    null, null, false, k.name.substringAfterLast('.', "").lowercase()
                )
                onProgress(out.size)
            }
        }
    }

    private fun children(ctx: Context, tree: Uri, parentId: String): List<Node> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val out = ArrayList<Node>()
        val cols = arrayOf(Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE)
        ctx.contentResolver.query(uri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                out += Node(id, c.getString(1) ?: "", c.getString(2) == Document.MIME_TYPE_DIR)
            }
        }
        return out
    }

    private fun readGame(ctx: Context, tree: Uri, dirId: String, dirName: String, metaId: String): Game {
        val mk = children(ctx, tree, metaId)
        val xmlNode = mk.firstOrNull { !it.isDir && it.name.equals("meta.xml", true) }
        val iconNode = mk.firstOrNull { !it.isDir && it.name.equals("iconTex.tga", true) }
        val fallback = dirName.ifEmpty { "Jogo" }
        var name = fallback
        var tid: String? = null
        if (xmlNode != null) {
            val xml = readBytes(ctx, tree, xmlNode.id, 256 * 1024)?.toString(Charsets.UTF_8)
            if (xml != null) {
                name = tag(xml, "longname_pt") ?: tag(xml, "longname_en")
                    ?: tag(xml, "shortname_pt") ?: tag(xml, "shortname_en") ?: fallback
                tid = tag(xml, "title_id")
            }
        }
        val icon = iconNode?.let { readBytes(ctx, tree, it.id, 2 * 1024 * 1024) }?.let { TgaDecoder.decode(it) }
        return Game(name, DocumentsContract.buildDocumentUriUsingTree(tree, dirId), tid, icon, true)
    }

    private fun readBytes(ctx: Context, tree: Uri, id: String, max: Int): ByteArray? {
        return try {
            val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
            val data = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (data != null && data.size <= max) data else null
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Localiza o .rpx principal de uma pasta de jogo (code/). Prefere o nome indicado em
     * code/app.xml (<argstr>); senão pega o primeiro .rpx.
     */
    fun findMainRpx(ctx: Context, gameUri: Uri): Uri? {
        val treeUri = DocumentsContract.buildTreeDocumentUri(gameUri.authority, DocumentsContract.getTreeDocumentId(gameUri))
        val dirId = DocumentsContract.getDocumentId(gameUri)
        val code = children(ctx, treeUri, dirId).firstOrNull { it.isDir && it.name.equals("code", true) } ?: return null
        val files = children(ctx, treeUri, code.id)
        val rpxs = files.filter { !it.isDir && it.name.endsWith(".rpx", true) }
        if (rpxs.isEmpty()) return null
        val appXml = files.firstOrNull { !it.isDir && it.name.equals("app.xml", true) }
        val wanted = appXml?.let { readBytes(ctx, treeUri, it.id, 256 * 1024)?.toString(Charsets.UTF_8) }?.let { tag(it, "argstr") }
        val pick = rpxs.firstOrNull { wanted != null && it.name.equals(wanted, true) } ?: rpxs.first()
        return DocumentsContract.buildDocumentUriUsingTree(treeUri, pick.id)
    }

    private fun tag(xml: String, t: String): String? {
        val m = Regex("<$t[^>]*>(.*?)</$t>", RegexOption.DOT_MATCHES_ALL).find(xml) ?: return null
        val s = m.groupValues[1]
            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&apos;", "'")
            .replace(Regex("\\s+"), " ").trim()
        return s.ifEmpty { null }
    }
}
