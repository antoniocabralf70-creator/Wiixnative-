package dev.wiiuemu.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    private lateinit var status: TextView
    private lateinit var grid: GridView
    private lateinit var settingsTab: GameSettingsTab
    private lateinit var controlsTab: ControlsTab
    private lateinit var tabViews: List<View>
    private val tabButtons = ArrayList<TextView>()
    private var currentTab = 0
    private var games: List<Game> = emptyList()
    private var scanGen = 0
    private var iconSize = 0

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) { /* sem permissão persistente: vale só nesta sessão */ }
            prefs.edit().putString("games_dir", uri.toString()).apply()
            refresh(uri)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)
        val gap = dp(10)
        val landscape = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
        val cols = if (landscape) 5 else 3
        val colW = (resources.displayMetrics.widthPixels - 2 * pad - (cols - 1) * gap) / cols
        iconSize = colW - dp(12)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(pad, dp(28), pad, pad)
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "WiiU Emu"; setTextColor(Ui.TEXT); textSize = 26f; typeface = Typeface.DEFAULT_BOLD
        }
        val infoBtn = Ui.button(this, "Info GPU").apply {
            setOnClickListener {
                val rep = if (EmulatorBridge.loaded) EmulatorBridge.nativeVulkanReport() else "Biblioteca nativa não carregada."
                AlertDialog.Builder(this@MainActivity).setTitle("Vulkan / GPU").setMessage(rep).setPositiveButton("OK", null).show()
            }
        }
        header.addView(title, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        header.addView(infoBtn, LinearLayout.LayoutParams(WRAP_CONTENT, dp(40)))
        root.addView(header, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // ----- barra de abas -----
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Jogos", "Config. jogos", "Controles").forEachIndexed { i, label ->
            val t = TextView(this).apply {
                text = label; gravity = Gravity.CENTER; textSize = 14f; setTextColor(Ui.TEXT)
                setOnClickListener { showTab(i) }
            }
            tabButtons += t
            bar.addView(t, LinearLayout.LayoutParams(0, dp(40), 1f).apply { if (i > 0) leftMargin = dp(6) })
        }
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12); bottomMargin = dp(8) })

        // ----- páginas -----
        val library = buildLibrary(cols, gap)
        settingsTab = GameSettingsTab(this, { games }) { g -> controlsTab.selectGame(g); showTab(2) }
        controlsTab = ControlsTab(this) { games }
        tabViews = listOf(library, settingsTab.root, controlsTab.root)
        val content = FrameLayout(this)
        tabViews.forEach { content.addView(it, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)) }
        root.addView(content, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // superfície mínima só para o relatório Vulkan
        val sv = SurfaceView(this)
        root.addView(sv, LinearLayout.LayoutParams(MATCH_PARENT, dp(2)))
        setContentView(root)
        if (EmulatorBridge.loaded) {
            sv.holder.addCallback(object : SurfaceHolder.Callback {
                override fun surfaceCreated(h: SurfaceHolder) { EmulatorBridge.nativeSurfaceCreated(h.surface) }
                override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
                override fun surfaceDestroyed(h: SurfaceHolder) { EmulatorBridge.nativeSurfaceDestroyed() }
            })
        }

        showTab(0)
        val saved = prefs.getString("games_dir", null)
        if (saved != null) refresh(Uri.parse(saved)) else status.text = "Nenhuma pasta escolhida."
    }

    override fun onPause() { controlsTab.saveIfDirty(); super.onPause() }

    private fun showTab(i: Int) {
        if (currentTab == 2 && i != 2) controlsTab.saveIfDirty()
        currentTab = i
        tabViews.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.GONE }
        tabButtons.forEachIndexed { k, t -> t.background = Ui.rounded(this, if (k == i) Ui.ACCENT else Ui.CARD, 12) }
    }

    private fun buildLibrary(cols: Int, gap: Int): View {
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply { setTextColor(Ui.MUTED); textSize = 13f }
        val pick = Ui.button(this, "Escolher pasta de jogos", true).apply { setOnClickListener { pickFolder.launch(null) } }
        grid = GridView(this).apply {
            numColumns = cols; horizontalSpacing = gap; verticalSpacing = gap
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ ->
                val g = games[pos]
                startActivity(Intent(this@MainActivity, EmulationActivity::class.java)
                    .putExtra("uri", g.uri.toString()).putExtra("name", g.name)
                    .putExtra("key", Store.gameKey(g)).putExtra("folder", g.isFolder).putExtra("ext", g.ext))
            }
            setOnItemLongClickListener { _, _, pos, _ -> settingsTab.select(games[pos]); showTab(1); true }
        }
        page.addView(status, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        page.addView(pick, LinearLayout.LayoutParams(MATCH_PARENT, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        page.addView(Ui.note(this, "Toque para jogar. Segure um jogo para abrir as configurações dele."))
        page.addView(grid, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) })
        return page
    }

    private fun refresh(tree: Uri) {
        status.text = "Procurando jogos..."
        val gen = ++scanGen
        Thread {
            var err: String? = null
            val found: List<Game> = try {
                GameScanner.scan(this, tree) { n -> runOnUiThread { if (gen == scanGen) status.text = "Procurando... $n" } }
            } catch (e: Exception) {
                err = e.message ?: e.javaClass.simpleName
                emptyList()
            }
            runOnUiThread {
                if (gen != scanGen) return@runOnUiThread
                games = found
                grid.adapter = GameAdapter(found)
                settingsTab.refresh(); controlsTab.refresh()
                status.text = when {
                    err != null -> "Erro ao ler a pasta: $err"
                    found.isEmpty() -> "Nenhum jogo encontrado. Escolha a pasta que contém as pastas dos jogos (com code, content e meta) ou arquivos .wua/.wud/.wux/.rpx."
                    else -> "${found.size} jogos"
                }
            }
        }.start()
    }

    private inner class GameAdapter(val items: List<Game>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val g = items[position]
            val ctx = this@MainActivity
            val card = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui.rounded(ctx, Ui.CARD, 12)
                setPadding(dp(6), dp(6), dp(6), dp(8))
            }
            val box = FrameLayout(ctx)
            val img = ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                if (g.icon != null) setImageBitmap(g.icon)
            }
            box.addView(img, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            if (g.icon == null) {
                box.background = Ui.rounded(ctx, Color.parseColor("#262B36"), 8)
                val letter = TextView(ctx).apply {
                    text = g.name.take(1).uppercase(); setTextColor(Ui.MUTED); textSize = 36f
                    typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
                }
                box.addView(letter, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
            }
            card.addView(box, LinearLayout.LayoutParams(MATCH_PARENT, iconSize))
            val name = TextView(ctx).apply {
                text = g.name; setTextColor(Ui.TEXT); textSize = 12f; maxLines = 2
                ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER_HORIZONTAL
            }
            card.addView(name, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
            return card
        }
    }
}
