package dev.wiiuemu.app

import android.content.Context

/** Persistência (SharedPreferences "cfg"). Chave de jogo = title_id ou hash da URI. */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun gameKey(g: Game): String = g.titleId ?: ("u" + g.uri.toString().hashCode())

    fun settings(c: Context, key: String) = GameSettings.fromJson(p(c).getString("game_$key", null))
    fun saveSettings(c: Context, key: String, s: GameSettings) { p(c).edit().putString("game_$key", s.toJson()).apply() }
    fun resetSettings(c: Context, key: String) { p(c).edit().remove("game_$key").apply() }

    /** key == null: perfil global. Para um jogo, devolve o perfil próprio se existir, senão o global. */
    fun controls(c: Context, key: String?): ControlConfig {
        val own = if (key != null) p(c).getString("controls_$key", null) else null
        return ControlConfig.fromJson(own ?: p(c).getString("controls_global", null))
    }
    fun hasOwnControls(c: Context, key: String) = p(c).getString("controls_$key", null) != null
    fun saveControls(c: Context, key: String?, cfg: ControlConfig) {
        p(c).edit().putString("controls_${key ?: "global"}", cfg.toJson().toString()).apply()
    }
    fun deleteControls(c: Context, key: String) { p(c).edit().remove("controls_$key").apply() }
}
