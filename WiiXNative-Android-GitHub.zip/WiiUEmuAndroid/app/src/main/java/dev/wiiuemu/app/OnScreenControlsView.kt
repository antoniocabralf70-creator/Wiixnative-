package dev.wiiuemu.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Controles na tela. Dois modos:
 *  - jogo: multitoque, deslizar entre botões, turbo, trava (toggle), analógico flutuante,
 *    tela touch do GamePad, zona morta/sensibilidade;
 *  - edição: arrastar para reposicionar, tocar para selecionar.
 */
class OnScreenControlsView(ctx: Context, var cfg: ControlConfig) : View(ctx) {

    interface Listener {
        fun onInput(buttons: Int, lx: Float, ly: Float, rx: Float, ry: Float, touch: Boolean, tx: Float, ty: Float)
    }

    var listener: Listener? = null
    var editMode = false
        set(v) { field = v; ptrs.clear(); latched.clear(); prevHeld = HashSet(); invalidate(); restartTicker() }
    var selected: ControlItem? = null
    var onSelect: ((ControlItem?) -> Unit)? = null
    var onChanged: (() -> Unit)? = null

    private class Ptr(var x: Float, var y: Float, var stickId: String?, var ox: Float, var oy: Float)

    private val ptrs = HashMap<Int, Ptr>()
    private val latched = HashSet<String>()
    private var prevHeld = HashSet<String>()
    private val pressed = HashSet<String>()
    private val knob = HashMap<String, FloatArray>()      // id -> [dx, dy] normalizado, para desenhar
    private val floatCenter = HashMap<String, FloatArray>()
    private var dpadMask = 0
    private var lastSig = ""
    private var dragDx = 0f
    private var dragDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.WHITE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }
    private val ticker = object : Runnable {
        override fun run() { if (!editMode && isAttachedToWindow) { recompute(); postDelayed(this, 16) } }
    }

    private fun restartTicker() { removeCallbacks(ticker); if (!editMode && isAttachedToWindow) post(ticker) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); restartTicker() }
    override fun onDetachedFromWindow() { removeCallbacks(ticker); super.onDetachedFromWindow() }

    // ---------- geometria ----------
    private fun cx(i: ControlItem) = i.x * width
    private fun cy(i: ControlItem) = i.y * height
    private fun rad(i: ControlItem) = i.size * min(width, height) * cfg.scale / 2f
    private fun near(i: ControlItem, x: Float, y: Float, k: Float) = hypot(x - cx(i), y - cy(i)) <= rad(i) * k
    private fun shown(i: ControlItem) = editMode || (i.visible && cfg.showControls)

    // ---------- desenho ----------
    override fun onDraw(c: Canvas) {
        val a = (cfg.opacity * 255).toInt().coerceIn(25, 255)
        for (it in cfg.items) {
            if (!shown(it)) continue
            val dim = editMode && !it.visible
            val alpha = if (dim) 60 else a
            val r = rad(it)
            val isOn = pressed.contains(it.id)
            fill.color = if (isOn) Ui.ACCENT else Color.WHITE
            fill.alpha = if (isOn) min(255, alpha + 80) else alpha / 3
            stroke.alpha = alpha
            stroke.pathEffect = if (dim) DashPathEffect(floatArrayOf(10f, 8f), 0f) else null
            when (it.kind) {
                Kind.BUTTON -> {
                    c.drawCircle(cx(it), cy(it), r, fill); c.drawCircle(cx(it), cy(it), r, stroke)
                    txt.alpha = alpha; txt.textSize = r * if (it.label.length > 2) 0.62f else 0.9f
                    c.drawText(it.label, cx(it), cy(it) + txt.textSize * 0.35f, txt)
                    if (it.turbo || it.toggle) {
                        txt.textSize = r * 0.4f
                        c.drawText(if (it.turbo && it.toggle) "T•L" else if (it.turbo) "T" else "L", cx(it) + r * 0.62f, cy(it) - r * 0.55f, txt)
                    }
                    if (it.toggle && latched.contains(it.id)) { stroke.color = Color.parseColor("#FFB020"); c.drawCircle(cx(it), cy(it), r + 6f, stroke); stroke.color = Color.WHITE }
                }
                Kind.DPAD -> drawDpad(c, it, r, alpha)
                Kind.STICK -> {
                    val fc = floatCenter[it.id]
                    val bx = fc?.get(0) ?: cx(it); val by = fc?.get(1) ?: cy(it)
                    c.drawCircle(bx, by, r, fill); c.drawCircle(bx, by, r, stroke)
                    val k = knob[it.id]
                    val kx = bx + (k?.get(0) ?: 0f) * r; val ky = by + (k?.get(1) ?: 0f) * r
                    fill.color = if (k != null) Ui.ACCENT else Color.WHITE; fill.alpha = min(255, alpha + 60)
                    c.drawCircle(kx, ky, r * 0.42f, fill)
                    txt.alpha = alpha; txt.textSize = r * 0.4f; c.drawText(it.label, kx, ky + txt.textSize * 0.35f, txt)
                }
            }
            if (editMode && it === selected) {
                val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f; color = Ui.ACCENT; pathEffect = DashPathEffect(floatArrayOf(14f, 8f), 0f) }
                c.drawCircle(cx(it), cy(it), r * 1.15f, p)
            }
        }
    }

    private fun drawDpad(c: Canvas, it: ControlItem, r: Float, alpha: Int) {
        val t = r * 0.34f
        val h = RectF(cx(it) - r, cy(it) - t, cx(it) + r, cy(it) + t)
        val v = RectF(cx(it) - t, cy(it) - r, cx(it) + t, cy(it) + r)
        fill.color = Color.WHITE; fill.alpha = alpha / 3
        c.drawRoundRect(h, t / 2, t / 2, fill); c.drawRoundRect(v, t / 2, t / 2, fill)
        c.drawRoundRect(h, t / 2, t / 2, stroke); c.drawRoundRect(v, t / 2, t / 2, stroke)
        fill.color = Ui.ACCENT; fill.alpha = min(255, alpha + 80)
        if (dpadMask and Btn.UP != 0) c.drawRoundRect(RectF(cx(it) - t, cy(it) - r, cx(it) + t, cy(it) - t / 2), 6f, 6f, fill)
        if (dpadMask and Btn.DOWN != 0) c.drawRoundRect(RectF(cx(it) - t, cy(it) + t / 2, cx(it) + t, cy(it) + r), 6f, 6f, fill)
        if (dpadMask and Btn.LEFT != 0) c.drawRoundRect(RectF(cx(it) - r, cy(it) - t, cx(it) - t / 2, cy(it) + t), 6f, 6f, fill)
        if (dpadMask and Btn.RIGHT != 0) c.drawRoundRect(RectF(cx(it) + t / 2, cy(it) - t, cx(it) + r, cy(it) + t), 6f, 6f, fill)
    }

    // ---------- toque ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editMode) return editTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val idx = e.actionIndex
                val p = Ptr(e.getX(idx), e.getY(idx), null, 0f, 0f)
                ptrs[e.getPointerId(idx)] = p
                captureStick(p)
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) ptrs[e.getPointerId(i)]?.let { it.x = e.getX(i); it.y = e.getY(i) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val p = ptrs.remove(e.getPointerId(e.actionIndex))
                p?.stickId?.let { knob.remove(it); floatCenter.remove(it) }
            }
            MotionEvent.ACTION_CANCEL -> { ptrs.clear(); knob.clear(); floatCenter.clear() }
        }
        recompute()
        return true
    }

    private fun overButton(x: Float, y: Float) = cfg.items.any {
        it.visible && it.kind != Kind.STICK && near(it, x, y, if (it.kind == Kind.DPAD) 1.15f else 1.1f)
    }

    private fun captureStick(p: Ptr) {
        if (!cfg.showControls || overButton(p.x, p.y)) return
        for (it in cfg.items) {
            if (it.kind != Kind.STICK || !it.visible) continue
            if (cfg.floatingStick && near(it, p.x, p.y, 2.4f)) {
                p.stickId = it.id; p.ox = p.x; p.oy = p.y; floatCenter[it.id] = floatArrayOf(p.x, p.y); return
            }
            if (near(it, p.x, p.y, 1.3f)) { p.stickId = it.id; p.ox = cx(it); p.oy = cy(it); return }
        }
    }

    private fun recompute() {
        var lx = 0f; var ly = 0f; var rx = 0f; var ry = 0f
        var touch = false; var tx = 0f; var ty = 0f
        val heldNow = HashSet<String>()
        var dp = 0
        for ((_, p) in ptrs) {
            val sid = p.stickId
            if (sid != null) {
                val it = cfg.items.firstOrNull { i -> i.id == sid } ?: continue
                val r = rad(it)
                val dx = (p.x - p.ox) / r; val dy = (p.y - p.oy) / r
                val len = hypot(dx, dy)
                val k = min(len, 1f)
                knob[sid] = if (len > 0f) floatArrayOf(dx / len * k, dy / len * k) else floatArrayOf(0f, 0f)
                val v = if (k < cfg.deadzone) 0f else min(1f, (k - cfg.deadzone) / (1f - cfg.deadzone) * cfg.sensitivity)
                val ox = if (len > 0f) dx / len * v else 0f; val oy = if (len > 0f) -dy / len * v else 0f
                if (it.stickSide == 0) { lx = ox; ly = oy } else { rx = ox; ry = oy }
                continue
            }
            var hit = false
            if (cfg.showControls) for (it in cfg.items) {
                if (!it.visible) continue
                when (it.kind) {
                    Kind.BUTTON -> if (near(it, p.x, p.y, 1.1f)) { heldNow += it.id; hit = true }
                    Kind.DPAD -> if (near(it, p.x, p.y, 1.15f)) {
                        hit = true
                        val dx = p.x - cx(it); val dy = p.y - cy(it); val t = rad(it) * 0.35f
                        if (dy < -t) dp = dp or Btn.UP; if (dy > t) dp = dp or Btn.DOWN
                        if (dx < -t) dp = dp or Btn.LEFT; if (dx > t) dp = dp or Btn.RIGHT
                    }
                    else -> {}
                }
            }
            if (!hit && cfg.touchScreen && !touch) { touch = true; tx = (p.x / width).coerceIn(0f, 1f); ty = (p.y / height).coerceIn(0f, 1f) }
        }
        // bordas de subida: haptics e travas (toggle)
        for (id in heldNow) if (!prevHeld.contains(id)) {
            val it = cfg.items.firstOrNull { i -> i.id == id } ?: continue
            if (it.toggle) { if (!latched.remove(id)) latched.add(id) }
            if (cfg.haptics) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
        prevHeld = heldNow
        val period = (500 / cfg.turboHz.coerceIn(1, 30)).toLong().coerceAtLeast(16)
        val phaseOn = (SystemClock.uptimeMillis() / period) % 2L == 0L
        var mask = dp
        val nowPressed = HashSet<String>()
        for (it in cfg.items) {
            if (it.kind != Kind.BUTTON || !it.visible) continue
            val active = if (it.toggle) latched.contains(it.id) else heldNow.contains(it.id)
            if (!active) continue
            nowPressed += it.id
            if (!it.turbo || phaseOn) mask = mask or it.mask
        }
        if (nowPressed != pressed || dp != dpadMask) { pressed.clear(); pressed.addAll(nowPressed); dpadMask = dp; invalidate() }
        else if (ptrs.isNotEmpty()) invalidate()
        val sig = "$mask|$lx|$ly|$rx|$ry|$touch|$tx|$ty"
        if (sig != lastSig) { lastSig = sig; listener?.onInput(mask, lx, ly, rx, ry, touch, tx, ty) }
    }

    // ---------- edição ----------
    private fun editTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = cfg.items.lastOrNull { near(it, e.x, e.y, 1.1f) }
                selected = hit; onSelect?.invoke(hit)
                if (hit != null) { dragDx = e.x - cx(hit); dragDy = e.y - cy(hit) }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> selected?.let {
                it.x = ((e.x - dragDx) / width).coerceIn(0.03f, 0.97f)
                it.y = ((e.y - dragDy) / height).coerceIn(0.04f, 0.96f)
                onChanged?.invoke(); invalidate()
            }
        }
        return true
    }
}
