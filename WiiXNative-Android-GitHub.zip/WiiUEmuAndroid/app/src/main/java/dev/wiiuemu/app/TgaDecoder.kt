package dev.wiiuemu.app

import android.graphics.Bitmap

/** Decodifica TGA (24/32 bits, normal ou RLE). É o formato do iconTex.tga dos jogos de Wii U. */
object TgaDecoder {
    fun decode(b: ByteArray): Bitmap? {
        try {
            if (b.size < 18) return null
            val idLen = b[0].toInt() and 0xFF
            val cmType = b[1].toInt() and 0xFF
            val type = b[2].toInt() and 0xFF
            if (cmType != 0 || (type != 2 && type != 10)) return null
            val w = (b[12].toInt() and 0xFF) or ((b[13].toInt() and 0xFF) shl 8)
            val h = (b[14].toInt() and 0xFF) or ((b[15].toInt() and 0xFF) shl 8)
            val bpp = b[16].toInt() and 0xFF
            val desc = b[17].toInt() and 0xFF
            if ((bpp != 24 && bpp != 32) || w <= 0 || h <= 0 || w > 4096 || h > 4096) return null
            val bytesPP = bpp / 8
            val topDown = (desc and 0x20) != 0
            val total = w * h
            val px = IntArray(total)
            var pos = 18 + idLen
            var i = 0

            fun readPx(p: Int): Int {
                val bl = b[p].toInt() and 0xFF
                val g = b[p + 1].toInt() and 0xFF
                val r = b[p + 2].toInt() and 0xFF
                val a = if (bytesPP == 4) (b[p + 3].toInt() and 0xFF) else 255
                return (a shl 24) or (r shl 16) or (g shl 8) or bl
            }

            if (type == 2) {
                while (i < total) {
                    px[i++] = readPx(pos)
                    pos += bytesPP
                }
            } else {
                while (i < total) {
                    val hdr = b[pos++].toInt() and 0xFF
                    val cnt = (hdr and 0x7F) + 1
                    if ((hdr and 0x80) != 0) {
                        val v = readPx(pos)
                        pos += bytesPP
                        var k = 0
                        while (k < cnt && i < total) { px[i++] = v; k++ }
                    } else {
                        var k = 0
                        while (k < cnt && i < total) { px[i++] = readPx(pos); pos += bytesPP; k++ }
                    }
                }
            }

            // Se todos os pixels têm alpha 0, o ícone ficaria invisível: força opaco.
            var anyAlpha = false
            for (p in px) if ((p ushr 24) != 0) { anyAlpha = true; break }
            if (!anyAlpha) for (k in px.indices) px[k] = px[k] or (0xFF shl 24)

            val out = if (topDown) px else {
                val flipped = IntArray(total)
                for (y in 0 until h) System.arraycopy(px, (h - 1 - y) * w, flipped, y * w, w)
                flipped
            }
            return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
        } catch (e: Exception) {
            return null
        }
    }
}
