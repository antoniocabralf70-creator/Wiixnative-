package dev.wiiuemu.app

import org.json.JSONArray
import org.json.JSONObject

/** Máscara de botões do GamePad. Mesmo contrato de core/input_state.h. */
object Btn {
    const val A = 1 shl 0; const val B = 1 shl 1; const val X = 1 shl 2; const val Y = 1 shl 3
    const val L = 1 shl 4; const val R = 1 shl 5; const val ZL = 1 shl 6; const val ZR = 1 shl 7
    const val PLUS = 1 shl 8; const val MINUS = 1 shl 9; const val HOME = 1 shl 10
    const val UP = 1 shl 11; const val DOWN = 1 shl 12; const val LEFT = 1 shl 13; const val RIGHT = 1 shl 14
    const val L3 = 1 shl 15; const val R3 = 1 shl 16
    val NAMES = listOf("A", "B", "X", "Y", "L", "R", "ZL", "ZR", "+", "-", "Home", "↑", "↓", "←", "→", "L3", "R3")
}

enum class Kind { BUTTON, DPAD, STICK }

class ControlItem(
    var id: String, var kind: Kind, var label: String, var mask: Int, var stickSide: Int,
    var x: Float, var y: Float, var size: Float,
    var visible: Boolean = true, var turbo: Boolean = false, var toggle: Boolean = false, var custom: Boolean = false
) {
    fun toJson() = JSONObject().put("id", id).put("kind", kind.name).put("label", label).put("mask", mask)
        .put("side", stickSide).put("x", x.toDouble()).put("y", y.toDouble()).put("size", size.toDouble())
        .put("visible", visible).put("turbo", turbo).put("toggle", toggle).put("custom", custom)

    companion object {
        fun fromJson(o: JSONObject) = ControlItem(
            o.getString("id"), Kind.valueOf(o.getString("kind")), o.optString("label"), o.optInt("mask"), o.optInt("side"),
            o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.5).toFloat(), o.optDouble("size", 0.14).toFloat(),
            o.optBoolean("visible", true), o.optBoolean("turbo"), o.optBoolean("toggle"), o.optBoolean("custom")
        )
    }
}

class ControlConfig {
    var items: MutableList<ControlItem> = defaultItems()
    var opacity = 0.6f            // 0.1..1
    var scale = 1.0f              // 0.5..1.6 (tamanho global)
    var showControls = true
    var haptics = true
    var deadzone = 0.12f          // zona morta dos analógicos
    var sensitivity = 1.0f        // ganho dos analógicos
    var floatingStick = false     // analógico flutuante: nasce onde o dedo toca
    var gyroAim = false           // mira por giroscópio no analógico direito
    var gyroSens = 1.0f
    var touchScreen = true        // toque fora dos botões = tela touch do GamePad
    var turboHz = 10              // cliques por segundo dos botões turbo

    fun toJson() = JSONObject().put("opacity", opacity.toDouble()).put("scale", scale.toDouble())
        .put("show", showControls).put("haptics", haptics).put("dz", deadzone.toDouble()).put("sens", sensitivity.toDouble())
        .put("floating", floatingStick).put("gyro", gyroAim).put("gyroSens", gyroSens.toDouble())
        .put("touch", touchScreen).put("turbo", turboHz)
        .put("items", JSONArray().also { a -> items.forEach { a.put(it.toJson()) } })

    companion object {
        fun fromJson(s: String?): ControlConfig {
            val c = ControlConfig()
            if (s == null) return c
            try {
                val o = JSONObject(s)
                c.opacity = o.optDouble("opacity", 0.6).toFloat(); c.scale = o.optDouble("scale", 1.0).toFloat()
                c.showControls = o.optBoolean("show", true); c.haptics = o.optBoolean("haptics", true)
                c.deadzone = o.optDouble("dz", 0.12).toFloat(); c.sensitivity = o.optDouble("sens", 1.0).toFloat()
                c.floatingStick = o.optBoolean("floating"); c.gyroAim = o.optBoolean("gyro")
                c.gyroSens = o.optDouble("gyroSens", 1.0).toFloat(); c.touchScreen = o.optBoolean("touch", true)
                c.turboHz = o.optInt("turbo", 10)
                val arr = o.optJSONArray("items")
                if (arr != null && arr.length() > 0) c.items = MutableList(arr.length()) { ControlItem.fromJson(arr.getJSONObject(it)) }
            } catch (e: Exception) { return ControlConfig() }
            return c
        }

        fun defaultItems(): MutableList<ControlItem> = mutableListOf(
            ControlItem("LS", Kind.STICK, "L", 0, 0, 0.13f, 0.47f, 0.30f),
            ControlItem("DPAD", Kind.DPAD, "", 0, 0, 0.13f, 0.82f, 0.26f),
            ControlItem("RS", Kind.STICK, "R", 0, 1, 0.68f, 0.80f, 0.26f),
            ControlItem("A", Kind.BUTTON, "A", Btn.A, 0, 0.93f, 0.60f, 0.14f),
            ControlItem("B", Kind.BUTTON, "B", Btn.B, 0, 0.86f, 0.76f, 0.14f),
            ControlItem("X", Kind.BUTTON, "X", Btn.X, 0, 0.86f, 0.44f, 0.14f),
            ControlItem("Y", Kind.BUTTON, "Y", Btn.Y, 0, 0.79f, 0.60f, 0.14f),
            ControlItem("L", Kind.BUTTON, "L", Btn.L, 0, 0.07f, 0.08f, 0.12f),
            ControlItem("ZL", Kind.BUTTON, "ZL", Btn.ZL, 0, 0.19f, 0.08f, 0.12f),
            ControlItem("R", Kind.BUTTON, "R", Btn.R, 0, 0.93f, 0.08f, 0.12f),
            ControlItem("ZR", Kind.BUTTON, "ZR", Btn.ZR, 0, 0.81f, 0.08f, 0.12f),
            ControlItem("MINUS", Kind.BUTTON, "-", Btn.MINUS, 0, 0.40f, 0.92f, 0.09f),
            ControlItem("HOME", Kind.BUTTON, "Home", Btn.HOME, 0, 0.50f, 0.92f, 0.09f),
            ControlItem("PLUS", Kind.BUTTON, "+", Btn.PLUS, 0, 0.60f, 0.92f, 0.09f),
            ControlItem("L3", Kind.BUTTON, "L3", Btn.L3, 0, 0.27f, 0.47f, 0.10f, visible = false),
            ControlItem("R3", Kind.BUTTON, "R3", Btn.R3, 0, 0.57f, 0.80f, 0.10f, visible = false)
        )
    }
}

/** Configurações por jogo. */
class GameSettings {
    var resScale = 1.0f       // escala interna pretendida: 0.10x..1.00x
    var fps = 60              // 30, 60 ou 0 (sem limite)
    var vsync = true
    var shaderCache = true
    var audio = true
    var diagHud = true
    var orientation = 0       // 0 = paisagem, 1 = livre (sensor)
    var language = "pt"
    var renderer = "Vulkan"

    fun toJson() = JSONObject().put("res", resScale).put("fps", fps).put("vsync", vsync).put("shaders", shaderCache)
        .put("audio", audio).put("hud", diagHud).put("orient", orientation).put("lang", language).put("renderer", renderer).toString()

    /** Formato "chave=valor;..." lido por core/emulator_core.cpp. */
    fun toNative() = "res=$resScale;fps=$fps;vsync=${b(vsync)};shaders=${b(shaderCache)};audio=${b(audio)};hud=${b(diagHud)};lang=$language;renderer=$renderer"
    private fun b(v: Boolean) = if (v) 1 else 0

    companion object {
        fun fromJson(s: String?): GameSettings {
            val g = GameSettings()
            if (s == null) return g
            try {
                val o = JSONObject(s)
                g.resScale = o.optDouble("res", 1.0).toFloat().coerceIn(0.10f, 1.0f); g.fps = o.optInt("fps", 60); g.vsync = o.optBoolean("vsync", true)
                g.shaderCache = o.optBoolean("shaders", true); g.audio = o.optBoolean("audio", true)
                g.diagHud = o.optBoolean("hud", true); g.orientation = o.optInt("orient", 0); g.language = o.optString("lang", "pt"); g.renderer = o.optString("renderer", "Vulkan")
            } catch (e: Exception) { return GameSettings() }
            return g
        }
    }
}
