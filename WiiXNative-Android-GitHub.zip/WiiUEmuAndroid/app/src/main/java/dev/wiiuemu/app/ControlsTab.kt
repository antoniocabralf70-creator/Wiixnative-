package dev.wiiuemu.app

import android.app.AlertDialog
import android.content.Context
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Aba "Controles": editor visual dos controles na tela, global ou por jogo. */
class ControlsTab(private val ctx: Context, private val games: () -> List<Game>) {
    val root: View
    private val page = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val previewBox = FrameLayout(ctx)
    private val profileBox = FrameLayout(ctx)
    private val selBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val optBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    private var profile: Game? = null          // null = global
    private var cfg = Store.controls(ctx, null)
    private var preview: OnScreenControlsView? = null
    private var dirty = false

    init {
        val pad = Ui.dp(ctx, 16)
        page.setPadding(0, 0, 0, pad)
        page.addView(profileBox)
        page.addView(Ui.note(ctx, "Toque num controle para selecionar; arraste para mover."), lp(top = 8))
        page.addView(previewBox, lp(top = 6))
        page.addView(selBox, lp(top = 8))
        page.addView(optBox)
        root = ScrollView(ctx).apply { addView(page, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }
        rebuild()
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = Ui.dp(ctx, top) }

    fun refresh() { rebuild() }

    /** Abre o editor já no perfil de um jogo. */
    fun selectGame(g: Game?) { saveIfDirty(); profile = g; cfg = Store.controls(ctx, g?.let { Store.gameKey(it) }); rebuild() }

    fun saveIfDirty() {
        if (!dirty) return
        Store.saveControls(ctx, profile?.let { Store.gameKey(it) }, cfg)
        dirty = false
    }

    private fun touched() { dirty = true }

    private fun rebuild() {
        // seletor de perfil
        val list = games()
        val names = listOf("Global (padrão)") + list.map { it.name }
        val sel = if (profile == null) 0 else (list.indexOfFirst { it.uri == profile!!.uri } + 1).coerceAtLeast(0)
        profileBox.removeAllViews()
        profileBox.addView(Ui.spinner(ctx, "Perfil", names, sel) { pos ->
            selectGame(if (pos == 0) null else games().getOrNull(pos - 1))
        })

        // pré-visualização no formato de tela do jogo (16:9)
        val w = ctx.resources.displayMetrics.widthPixels - 2 * Ui.dp(ctx, 16)
        previewBox.removeAllViews()
        val v = OnScreenControlsView(ctx, cfg).apply {
            editMode = true
            setBackgroundColor(android.graphics.Color.parseColor("#14171D"))
            onSelect = { buildSelection(it) }
            onChanged = { touched() }
        }
        preview = v
        previewBox.addView(v, FrameLayout.LayoutParams(MATCH_PARENT, w * 9 / 16))
        buildSelection(null)
        buildOptions()
    }

    private fun buildSelection(item: ControlItem?) {
        selBox.removeAllViews()
        if (item == null) { selBox.addView(Ui.note(ctx, "Nenhum controle selecionado.")); return }
        val card = Ui.card(ctx)
        val name = when (item.kind) { Kind.DPAD -> "Direcional"; Kind.STICK -> "Analógico ${item.label}"; else -> "Botão ${item.label}" }
        card.addView(TextView(ctx).apply { text = name; setTextColor(Ui.TEXT); textSize = 16f })
        card.addView(Ui.seek(ctx, "Tamanho", 6, 45, (item.size * 100).toInt(), { v -> "$v%" }) { v -> item.size = v / 100f; touched(); preview?.invalidate() })
        card.addView(Ui.switch(ctx, "Visível", item.visible) { v -> item.visible = v; touched(); preview?.invalidate() })
        if (item.kind == Kind.BUTTON) {
            card.addView(Ui.switch(ctx, "Turbo (repete enquanto segura)", item.turbo) { v -> item.turbo = v; touched(); preview?.invalidate() })
            card.addView(Ui.switch(ctx, "Trava (toque liga/desliga)", item.toggle) { v -> item.toggle = v; touched(); preview?.invalidate() })
        }
        if (item.custom) card.addView(Ui.button(ctx, "Remover este botão").apply {
            setOnClickListener { cfg.items.remove(item); touched(); preview?.selected = null; preview?.invalidate(); buildSelection(null) }
        }, lp(top = 8))
        selBox.addView(card)
    }

    private fun buildOptions() {
        optBox.removeAllViews()
        val c = cfg
        val card = Ui.card(ctx)
        card.addView(Ui.section(ctx, "GERAL"))
        card.addView(Ui.switch(ctx, "Mostrar controles na tela", c.showControls) { v -> c.showControls = v; touched() })
        card.addView(Ui.seek(ctx, "Opacidade", 10, 100, (c.opacity * 100).toInt(), { v -> "$v%" }) { v -> c.opacity = v / 100f; touched(); preview?.invalidate() })
        card.addView(Ui.seek(ctx, "Tamanho global", 50, 160, (c.scale * 100).toInt(), { v -> "$v%" }) { v -> c.scale = v / 100f; touched(); preview?.invalidate() })
        card.addView(Ui.switch(ctx, "Vibração ao tocar", c.haptics) { v -> c.haptics = v; touched() })
        card.addView(Ui.section(ctx, "ANALÓGICOS"))
        card.addView(Ui.seek(ctx, "Zona morta", 0, 40, (c.deadzone * 100).toInt(), { v -> "$v%" }) { v -> c.deadzone = v / 100f; touched() })
        card.addView(Ui.seek(ctx, "Sensibilidade", 50, 200, (c.sensitivity * 100).toInt(), { v -> "$v%" }) { v -> c.sensitivity = v / 100f; touched() })
        card.addView(Ui.switch(ctx, "Analógico flutuante (nasce onde você toca)", c.floatingStick) { v -> c.floatingStick = v; touched() })
        card.addView(Ui.section(ctx, "EXTREMOS"))
        card.addView(Ui.switch(ctx, "Mira por giroscópio (analógico direito)", c.gyroAim) { v -> c.gyroAim = v; touched() })
        card.addView(Ui.seek(ctx, "Sensibilidade do giroscópio", 20, 300, (c.gyroSens * 100).toInt(), { v -> "$v%" }) { v -> c.gyroSens = v / 100f; touched() })
        card.addView(Ui.switch(ctx, "Tela touch do GamePad (toque fora dos botões)", c.touchScreen) { v -> c.touchScreen = v; touched() })
        card.addView(Ui.seek(ctx, "Velocidade do turbo", 2, 30, c.turboHz, { v -> "$v/s" }) { v -> c.turboHz = v; touched() })
        card.addView(Ui.note(ctx, "Turbo e Trava são configurados por botão. \"Adicionar botão\" cria combos (vários botões num toque)."), lp(top = 6))
        optBox.addView(card, lp(top = 10))

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.button(ctx, "Adicionar botão").apply { setOnClickListener { addButtonDialog() } }, LinearLayout.LayoutParams(0, Ui.dp(ctx, 48), 1f).apply { rightMargin = Ui.dp(ctx, 8) })
        row.addView(Ui.button(ctx, "Redefinir").apply { setOnClickListener { resetDialog() } }, LinearLayout.LayoutParams(0, Ui.dp(ctx, 48), 1f).apply { rightMargin = Ui.dp(ctx, 8) })
        row.addView(Ui.button(ctx, "Salvar", true).apply {
            setOnClickListener { dirty = true; saveIfDirty(); Toast.makeText(ctx, "Controles salvos.", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(0, Ui.dp(ctx, 48), 1f))
        optBox.addView(row, lp(top = 12))

        val g = profile
        if (g != null && Store.hasOwnControls(ctx, Store.gameKey(g))) {
            optBox.addView(Ui.button(ctx, "Usar o perfil global neste jogo").apply {
                setOnClickListener { Store.deleteControls(ctx, Store.gameKey(g)); dirty = false; selectGame(g) }
            }, lp(top = 8))
        } else if (g != null) {
            optBox.addView(Ui.note(ctx, "Este jogo usa o perfil global. Ao salvar, ele passa a ter um perfil próprio."), lp(top = 8))
        }
    }

    private fun addButtonDialog() {
        val checked = BooleanArray(Btn.NAMES.size)
        AlertDialog.Builder(ctx).setTitle("Botões deste controle (marque vários para um combo)")
            .setMultiChoiceItems(Btn.NAMES.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Adicionar") { _, _ ->
                var mask = 0
                val names = ArrayList<String>()
                for (i in checked.indices) if (checked[i]) { mask = mask or (1 shl i); names += Btn.NAMES[i] }
                if (mask == 0) return@setPositiveButton
                val label = if (names.size <= 2) names.joinToString("+") else "Combo"
                val item = ControlItem("C" + System.currentTimeMillis(), Kind.BUTTON, label, mask, 0, 0.5f, 0.5f, 0.13f, custom = true)
                cfg.items.add(item); touched()
                preview?.selected = item; preview?.invalidate(); buildSelection(item)
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun resetDialog() {
        AlertDialog.Builder(ctx).setTitle("Redefinir controles?")
            .setMessage("Posições, tamanhos e opções voltam ao padrão (botões criados por você serão removidos).")
            .setPositiveButton("Redefinir") { _, _ -> cfg = ControlConfig(); dirty = true; rebuild() }
            .setNegativeButton("Cancelar", null).show()
    }
}
