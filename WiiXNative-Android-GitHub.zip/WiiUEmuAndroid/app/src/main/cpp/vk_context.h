#pragma once
#include <string>
struct ANativeWindow;

// Cria instância Vulkan + surface Android e coleta informações do aparelho.
// Base para o futuro backend Latte -> Vulkan.
namespace vkctx {
bool Init(ANativeWindow* window);
void Shutdown();
std::string Report();
}
