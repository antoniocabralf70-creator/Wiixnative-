#include "vk_context.h"
#include <android/log.h>
#include <android/native_window.h>
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_android.h>
#include <vector>
#include <string>

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "wiiuemu", __VA_ARGS__)

namespace {
VkInstance g_instance = VK_NULL_HANDLE;
VkSurfaceKHR g_surface = VK_NULL_HANDLE;
std::string g_report = "Vulkan não inicializado.";

std::string Ver(uint32_t v) {
    return std::to_string(VK_VERSION_MAJOR(v)) + "." + std::to_string(VK_VERSION_MINOR(v)) + "." +
           std::to_string(VK_VERSION_PATCH(v));
}
}  // namespace

namespace vkctx {

void Shutdown() {
    if (g_surface) { vkDestroySurfaceKHR(g_instance, g_surface, nullptr); g_surface = VK_NULL_HANDLE; }
    if (g_instance) { vkDestroyInstance(g_instance, nullptr); g_instance = VK_NULL_HANDLE; }
}

bool Init(ANativeWindow* window) {
    Shutdown();
    uint32_t instVer = VK_API_VERSION_1_0;
    auto enumVer = reinterpret_cast<PFN_vkEnumerateInstanceVersion>(
        vkGetInstanceProcAddr(nullptr, "vkEnumerateInstanceVersion"));
    if (enumVer) enumVer(&instVer);

    const char* exts[] = {VK_KHR_SURFACE_EXTENSION_NAME, VK_KHR_ANDROID_SURFACE_EXTENSION_NAME};
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "WiiUEmu";
    app.apiVersion = instVer >= VK_API_VERSION_1_1 ? VK_API_VERSION_1_1 : VK_API_VERSION_1_0;
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ci.pApplicationInfo = &app;
    ci.enabledExtensionCount = 2;
    ci.ppEnabledExtensionNames = exts;
    if (vkCreateInstance(&ci, nullptr, &g_instance) != VK_SUCCESS) {
        g_report = "Erro: vkCreateInstance falhou (sem Vulkan utilizável).";
        LOGE("%s", g_report.c_str());
        return false;
    }

    VkAndroidSurfaceCreateInfoKHR sci{VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR};
    sci.window = window;
    if (vkCreateAndroidSurfaceKHR(g_instance, &sci, nullptr, &g_surface) != VK_SUCCESS) {
        g_report = "Erro: não foi possível criar a surface Vulkan.";
        LOGE("%s", g_report.c_str());
        return false;
    }

    uint32_t n = 0;
    vkEnumeratePhysicalDevices(g_instance, &n, nullptr);
    std::vector<VkPhysicalDevice> devs(n);
    vkEnumeratePhysicalDevices(g_instance, &n, devs.data());
    if (n == 0) { g_report = "Erro: nenhuma GPU Vulkan encontrada."; return false; }

    g_report = "Vulkan instância: " + Ver(instVer) + "\n";
    for (auto d : devs) {
        VkPhysicalDeviceProperties p;
        vkGetPhysicalDeviceProperties(d, &p);
        uint32_t qn = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(d, &qn, nullptr);
        bool present = false;
        for (uint32_t i = 0; i < qn && !present; i++) {
            VkBool32 ok = VK_FALSE;
            vkGetPhysicalDeviceSurfaceSupportKHR(d, i, g_surface, &ok);
            present = ok == VK_TRUE;
        }
        g_report += std::string("GPU: ") + p.deviceName + "\nAPI do driver: " + Ver(p.apiVersion) +
                    "\nApresentação: " + (present ? "ok" : "NÃO suportada") + "\n";
        if (p.apiVersion < VK_API_VERSION_1_1)
            g_report += "AVISO: driver abaixo de Vulkan 1.1; o backend gráfico não vai funcionar.\n";
    }
    return true;
}

std::string Report() { return g_report; }

}  // namespace vkctx
