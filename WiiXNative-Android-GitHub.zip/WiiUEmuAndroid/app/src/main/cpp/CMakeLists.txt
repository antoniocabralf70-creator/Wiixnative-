cmake_minimum_required(VERSION 3.22.1)
project(wiiuemu LANGUAGES CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(wiiuemu SHARED
    jni_bridge.cpp
    vk_context.cpp
    core/emulator_core.cpp
    core/ppc.cpp
    core/rpx_loader.cpp)

target_include_directories(wiiuemu PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_definitions(wiiuemu PRIVATE VK_USE_PLATFORM_ANDROID_KHR=1)
find_library(log-lib log)
target_link_libraries(wiiuemu android vulkan z ${log-lib})
