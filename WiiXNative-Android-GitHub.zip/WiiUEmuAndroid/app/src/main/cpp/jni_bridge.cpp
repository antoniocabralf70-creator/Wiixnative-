#include <jni.h>
#include <android/native_window_jni.h>
#include "vk_context.h"
#include "core/emulator_core.h"

static ANativeWindow* g_window = nullptr;  // superfície mínima da tela principal (relatório Vulkan)

static std::string Str(JNIEnv* env, jstring s) {
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" {

JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeSurfaceCreated(JNIEnv* env, jobject, jobject surface) {
    if (g_window) ANativeWindow_release(g_window);
    g_window = ANativeWindow_fromSurface(env, surface);
    vkctx::Init(g_window);
}
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeSurfaceDestroyed(JNIEnv*, jobject) {
    vkctx::Shutdown();
    if (g_window) { ANativeWindow_release(g_window); g_window = nullptr; }
}
JNIEXPORT jstring JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeVulkanReport(JNIEnv* env, jobject) {
    return env->NewStringUTF(vkctx::Report().c_str());
}
JNIEXPORT jstring JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeLoadTitle(JNIEnv* env, jobject, jstring path) {
    return env->NewStringUTF(core::LoadTitle(Str(env, path)).c_str());
}

// ---- tela de emulação ----
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeEmuSurface(JNIEnv* env, jobject, jobject surface) {
    core::SetWindow(surface ? ANativeWindow_fromSurface(env, surface) : nullptr);
}
JNIEXPORT jstring JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeStart(JNIEnv* env, jobject, jint fd, jstring ext, jstring name, jstring settings) {
    return env->NewStringUTF(core::Start(fd, Str(env, ext), Str(env, name), Str(env, settings)).c_str());
}
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativePause(JNIEnv*, jobject, jboolean p) { core::Pause(p); }
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeStop(JNIEnv*, jobject) { core::Stop(); }
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeSetInput(JNIEnv*, jobject, jint b, jfloat lx, jfloat ly, jfloat rx, jfloat ry) {
    core::SetInput((uint32_t)b, lx, ly, rx, ry);
}
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeSetTouch(JNIEnv*, jobject, jboolean d, jfloat x, jfloat y) { core::SetTouch(d, x, y); }
JNIEXPORT void JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeSetGyro(JNIEnv*, jobject, jfloat x, jfloat y, jfloat z) { core::SetGyro(x, y, z); }
JNIEXPORT jstring JNICALL Java_dev_wiiuemu_app_EmulatorBridge_nativeStatus(JNIEnv* env, jobject) {
    return env->NewStringUTF(core::Status().c_str());
}

}  // extern "C"
