#pragma once
#include <cstdint>
#include <string>

struct ANativeWindow;

// Núcleo do emulador. Módulos hoje:
//   loader (RPX) -> memória -> CPU PowerPC (interpretador) -> vídeo (framebuffer) -> entrada
// Faltam: descriptografia WUA/WUD/WUX, Cafe OS (HLE), GPU Latte->Vulkan, áudio, JIT ARM64.
namespace core {
std::string LoadTitle(const std::string& path);  // compatibilidade com a versão anterior

// settings: "chave=valor;chave=valor" (res, fps, vsync, shaders, audio, hud, lang)
std::string Start(int fd, const std::string& ext, const std::string& name, const std::string& settings);
void Pause(bool paused);
void Stop();
void SetWindow(ANativeWindow* w);

void SetInput(uint32_t buttons, float lx, float ly, float rx, float ry);
void SetTouch(bool down, float x, float y);
void SetGyro(float x, float y, float z);
std::string Status();
}  // namespace core
