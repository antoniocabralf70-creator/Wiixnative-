#include "core/ppc.h"
#include <cstdio>

namespace core {
namespace {
inline uint32_t Rotl(uint32_t v, int n) { n &= 31; return n ? (v << n) | (v >> (32 - n)) : v; }
inline uint32_t Mask(int mb, int me) {
    uint32_t a = 0xFFFFFFFFu >> mb, b = 0xFFFFFFFFu << (31 - me);
    return mb <= me ? (a & b) : (a | b);
}
inline int32_t SExt16(uint32_t v) { return (int16_t)(v & 0xFFFF); }
}  // namespace

void Cpu::Halt(const std::string& why) { halted = true; haltReason = why; }

void Cpu::SetCR0(int32_t v) {
    uint32_t f = (v < 0 ? 8 : v > 0 ? 4 : 2) | ((xer >> 31) & 1);
    cr = (cr & 0x0FFFFFFFu) | (f << 28);
}
void Cpu::SetCRF(int f, int32_t a, int32_t b) {
    uint32_t v = (a < b ? 8 : a > b ? 4 : 2) | ((xer >> 31) & 1);
    int s = 28 - 4 * f; cr = (cr & ~(0xFu << s)) | (v << s);
}
void Cpu::SetCRFU(int f, uint32_t a, uint32_t b) {
    uint32_t v = (a < b ? 8 : a > b ? 4 : 2) | ((xer >> 31) & 1);
    int s = 28 - 4 * f; cr = (cr & ~(0xFu << s)) | (v << s);
}

void Cpu::Run(uint64_t maxInstr) { for (uint64_t i = 0; i < maxInstr && !halted; ++i) Step(); }

bool Cpu::Step() {
    if (halted) return false;
    uint32_t i;
    if (!mem->Read32(pc, i)) { char b[80]; snprintf(b, sizeof b, "busca de instrução inválida em 0x%08X", pc); Halt(b); return false; }
    uint32_t next = pc + 4;
    const uint32_t op = i >> 26;
    const int rD = (i >> 21) & 31, rA = (i >> 16) & 31, rB = (i >> 11) & 31;
    const bool rc = i & 1;
    const int32_t simm = SExt16(i);
    const uint32_t uimm = i & 0xFFFF;
    auto fault = [&](uint32_t ea) { char b[96]; snprintf(b, sizeof b, "acesso inválido a 0x%08X (PC=0x%08X)", ea, pc); Halt(b); };
    auto bad = [&]() { char b[96]; snprintf(b, sizeof b, "instrução 0x%08X não suportada (PC=0x%08X)", i, pc); Halt(b); };
    auto base = [&]() { return rA ? gpr[rA] : 0u; };
    uint32_t v = 0;

    switch (op) {
    case 7:  gpr[rD] = (uint32_t)((int32_t)gpr[rA] * simm); break;
    case 8: { uint64_t r = (uint64_t)(~gpr[rA]) + (uint32_t)simm + 1; gpr[rD] = (uint32_t)r; xer = (xer & ~0x20000000u) | ((r >> 32) ? 0x20000000u : 0); break; }
    case 10: SetCRFU((i >> 23) & 7, gpr[rA], uimm); break;
    case 11: SetCRF((i >> 23) & 7, (int32_t)gpr[rA], simm); break;
    case 12: case 13: {
        uint64_t r = (uint64_t)gpr[rA] + (uint32_t)simm; gpr[rD] = (uint32_t)r;
        xer = (xer & ~0x20000000u) | ((r >> 32) ? 0x20000000u : 0);
        if (op == 13) SetCR0((int32_t)gpr[rD]);
        break; }
    case 14: gpr[rD] = base() + (uint32_t)simm; break;
    case 15: gpr[rD] = base() + (uimm << 16); break;
    case 16: {  // bc
        uint32_t bo = rD, bi = rA;
        if (!(bo & 4)) ctr--;
        bool ctrOk = (bo & 4) || ((ctr != 0) != ((bo >> 1) & 1));
        bool condOk = (bo & 16) || (CrBit(bi) == (bool)((bo >> 3) & 1));
        uint32_t tgt = (i & 2) ? (uint32_t)(int16_t)(i & 0xFFFC) : pc + (uint32_t)(int16_t)(i & 0xFFFC);
        if (i & 1) lr = pc + 4;
        if (ctrOk && condOk) next = tgt;
        break; }
    case 17: { char b[96]; snprintf(b, sizeof b, "syscall r0=%u: Cafe OS (HLE) ainda não implementado", gpr[0]); Halt(b); return false; }
    case 18: {
        int32_t li = ((int32_t)(i & 0x03FFFFFC) << 6) >> 6;
        uint32_t tgt = (i & 2) ? (uint32_t)li : pc + (uint32_t)li;
        if (i & 1) lr = pc + 4;
        next = tgt; break; }
    case 19: {
        uint32_t xo = (i >> 1) & 0x3FF;
        if (xo == 16 || xo == 528) {
            uint32_t bo = rD, bi = rA;
            if (xo == 16 && !(bo & 4)) ctr--;
            bool ctrOk = (bo & 4) || ((ctr != 0) != ((bo >> 1) & 1));
            bool condOk = (bo & 16) || (CrBit(bi) == (bool)((bo >> 3) & 1));
            uint32_t tgt = (xo == 16 ? lr : ctr) & ~3u;
            if (i & 1) lr = pc + 4;
            if (ctrOk && condOk) next = tgt;
        } else if (xo == 150) { /* isync */ }
        else if (xo == 257 || xo == 449 || xo == 193 || xo == 225 || xo == 129 || xo == 33 || xo == 289 || xo == 417) {
            int d = rD, a = rA, b = rB;  // operações lógicas em bits do CR
            bool x = CrBit(a), y = CrBit(b), r = false;
            switch (xo) { case 257: r = x & y; break; case 449: r = x | y; break; case 193: r = x ^ y; break;
                          case 225: r = !(x & y); break; case 129: r = x & !y; break; case 33: r = !(x | y); break;
                          case 289: r = x == y; break; case 417: r = x | !y; break; }
            int s = 31 - d; cr = (cr & ~(1u << s)) | ((uint32_t)r << s);
        } else bad();
        break; }
    case 20: { int sh = rB, mb = (i >> 6) & 31, me = (i >> 1) & 31; uint32_t m = Mask(mb, me);
        gpr[rA] = (Rotl(gpr[rD], sh) & m) | (gpr[rA] & ~m); if (rc) SetCR0((int32_t)gpr[rA]); break; }
    case 21: { int sh = rB, mb = (i >> 6) & 31, me = (i >> 1) & 31;
        gpr[rA] = Rotl(gpr[rD], sh) & Mask(mb, me); if (rc) SetCR0((int32_t)gpr[rA]); break; }
    case 23: { int mb = (i >> 6) & 31, me = (i >> 1) & 31;
        gpr[rA] = Rotl(gpr[rD], gpr[rB] & 31) & Mask(mb, me); if (rc) SetCR0((int32_t)gpr[rA]); break; }
    case 24: gpr[rA] = gpr[rD] | uimm; break;
    case 25: gpr[rA] = gpr[rD] | (uimm << 16); break;
    case 26: gpr[rA] = gpr[rD] ^ uimm; break;
    case 27: gpr[rA] = gpr[rD] ^ (uimm << 16); break;
    case 28: gpr[rA] = gpr[rD] & uimm; SetCR0((int32_t)gpr[rA]); break;
    case 29: gpr[rA] = gpr[rD] & (uimm << 16); SetCR0((int32_t)gpr[rA]); break;
    case 31: {
        uint32_t xo10 = (i >> 1) & 0x3FF, xo9 = xo10 & 0x1FF;
        uint32_t s = gpr[rD], a = gpr[rA], b = gpr[rB];
        bool handled = true;
        switch (xo10) {
        case 0:   SetCRF((i >> 23) & 7, (int32_t)a, (int32_t)b); break;
        case 32:  SetCRFU((i >> 23) & 7, a, b); break;
        case 19:  gpr[rD] = cr; break;
        case 144: { uint32_t crm = (i >> 12) & 0xFF, m = 0; for (int k = 0; k < 8; ++k) if (crm & (0x80 >> k)) m |= 0xFu << (28 - 4 * k); cr = (cr & ~m) | (s & m); break; }
        case 83:  gpr[rD] = msr; break;
        case 146: msr = s; break;
        case 339: { uint32_t n = ((i >> 16) & 31) | (((i >> 11) & 31) << 5);
                    gpr[rD] = n == 1 ? xer : n == 8 ? lr : n == 9 ? ctr : sprs[n]; break; }
        case 467: { uint32_t n = ((i >> 16) & 31) | (((i >> 11) & 31) << 5);
                    if (n == 1) xer = s; else if (n == 8) lr = s; else if (n == 9) ctr = s; else sprs[n] = s; break; }
        case 28:  gpr[rA] = s & b; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 60:  gpr[rA] = s & ~b; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 444: gpr[rA] = s | b; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 412: gpr[rA] = s | ~b; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 316: gpr[rA] = s ^ b; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 476: gpr[rA] = ~(s & b); if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 124: gpr[rA] = ~(s | b); if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 284: gpr[rA] = ~(s ^ b); if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 24:  gpr[rA] = (b & 0x3F) > 31 ? 0 : s << (b & 0x3F); if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 536: gpr[rA] = (b & 0x3F) > 31 ? 0 : s >> (b & 0x3F); if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 792: case 824: {
            int n = xo10 == 824 ? rB : (b & 0x3F); int32_t sv = (int32_t)s; uint32_t ca;
            if (n > 31) { gpr[rA] = sv < 0 ? 0xFFFFFFFFu : 0; ca = sv < 0; }
            else { gpr[rA] = (uint32_t)(sv >> n); ca = sv < 0 && n && (s & ((1u << n) - 1)); }
            xer = (xer & ~0x20000000u) | (ca ? 0x20000000u : 0); if (rc) SetCR0((int32_t)gpr[rA]); break; }
        case 26:  gpr[rA] = s ? (uint32_t)__builtin_clz(s) : 32; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 922: gpr[rA] = (uint32_t)(int32_t)(int16_t)s; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 954: gpr[rA] = (uint32_t)(int32_t)(int8_t)s; if (rc) SetCR0((int32_t)gpr[rA]); break;
        case 23: case 20: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Read32(ea, v)) { fault(ea); return false; } gpr[rD] = v; break; }
        case 87:  { uint32_t ea = (rA ? a : 0) + b; if (!mem->Read8(ea, v)) { fault(ea); return false; } gpr[rD] = v; break; }
        case 279: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Read16(ea, v)) { fault(ea); return false; } gpr[rD] = v; break; }
        case 343: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Read16(ea, v)) { fault(ea); return false; } gpr[rD] = (uint32_t)SExt16(v); break; }
        case 151: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Write32(ea, s)) { fault(ea); return false; } break; }
        case 215: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Write8(ea, s)) { fault(ea); return false; } break; }
        case 407: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Write16(ea, s)) { fault(ea); return false; } break; }
        case 150: { uint32_t ea = (rA ? a : 0) + b; if (!mem->Write32(ea, s)) { fault(ea); return false; }
                    cr = (cr & 0x0FFFFFFFu) | (2u << 28); break; }  // stwcx.: sempre bem-sucedido (1 núcleo)
        case 1014: { uint32_t ea = ((rA ? a : 0) + b) & ~31u; for (int k = 0; k < 32; k += 4) mem->Write32(ea + k, 0); break; }
        case 598: case 854: case 86: case 54: case 278: case 982: case 246: case 470: break;  // sync/eieio/dcb*/icbi
        default: handled = false;
        }
        if (handled) break;
        switch (xo9) {
        case 266: gpr[rD] = a + b; if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 40:  gpr[rD] = b - a; if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 104: gpr[rD] = (uint32_t)(-(int32_t)a); if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 235: gpr[rD] = (uint32_t)((int32_t)a * (int32_t)b); if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 75:  gpr[rD] = (uint32_t)(((int64_t)(int32_t)a * (int32_t)b) >> 32); if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 11:  gpr[rD] = (uint32_t)(((uint64_t)a * b) >> 32); if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 491: gpr[rD] = (b == 0 || ((int32_t)a == INT32_MIN && (int32_t)b == -1)) ? 0 : (uint32_t)((int32_t)a / (int32_t)b); if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 459: gpr[rD] = b ? a / b : 0; if (rc) SetCR0((int32_t)gpr[rD]); break;
        case 10:  { uint64_t r = (uint64_t)a + b; gpr[rD] = (uint32_t)r; xer = (xer & ~0x20000000u) | ((r >> 32) ? 0x20000000u : 0); if (rc) SetCR0((int32_t)gpr[rD]); break; }
        case 8:   { uint64_t r = (uint64_t)(~a) + b + 1; gpr[rD] = (uint32_t)r; xer = (xer & ~0x20000000u) | ((r >> 32) ? 0x20000000u : 0); if (rc) SetCR0((int32_t)gpr[rD]); break; }
        default: bad();
        }
        break; }
    case 32: case 33: case 34: case 35: case 40: case 41: case 42: case 43: {
        uint32_t ea = base() + (uint32_t)simm; bool ok;
        if (op <= 33) ok = mem->Read32(ea, v);
        else if (op <= 35) ok = mem->Read8(ea, v);
        else if (op <= 41) ok = mem->Read16(ea, v);
        else { ok = mem->Read16(ea, v); v = (uint32_t)SExt16(v); }
        if (!ok) { fault(ea); return false; }
        gpr[rD] = v;
        if ((op == 33 || op == 35 || op == 41 || op == 43) && rA) gpr[rA] = ea;
        break; }
    case 36: case 37: case 38: case 39: case 44: case 45: {
        uint32_t ea = base() + (uint32_t)simm; bool ok;
        if (op <= 37) ok = mem->Write32(ea, gpr[rD]);
        else if (op <= 39) ok = mem->Write8(ea, gpr[rD]);
        else ok = mem->Write16(ea, gpr[rD]);
        if (!ok) { fault(ea); return false; }
        if ((op == 37 || op == 39 || op == 45) && rA) gpr[rA] = ea;
        break; }
    case 46: { uint32_t ea = base() + (uint32_t)simm; for (int r = rD; r < 32; ++r, ea += 4) { if (!mem->Read32(ea, v)) { fault(ea); return false; } gpr[r] = v; } break; }
    case 47: { uint32_t ea = base() + (uint32_t)simm; for (int r = rD; r < 32; ++r, ea += 4) if (!mem->Write32(ea, gpr[r])) { fault(ea); return false; } break; }
    default: bad(); return false;
    }
    if (halted) return false;
    pc = next; ++executed;
    return true;
}

}  // namespace core
