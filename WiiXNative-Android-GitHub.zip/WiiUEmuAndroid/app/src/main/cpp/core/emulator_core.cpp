#include "core/emulator_core.h"
#include <android/log.h>
#include <android/native_window.h>
#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <chrono>
#include <cmath>
#include <map>
#include <memory>
#include <mutex>
#include <sstream>
#include <thread>
#include <unistd.h>
#include <vector>
#include "core/input_state.h"
#include "core/memory.h"
#include "core/ppc.h"
#include "core/rpx_loader.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "wiiuemu", __VA_ARGS__)

namespace core {
namespace {
constexpr int W = 854, H = 480;

struct Settings {
    float res = 1.0f; int fps = 60;
    bool vsync = true, shaders = true, audio = true, hud = true;
    std::string lang = "pt";
};

Settings ParseSettings(const std::string& s) {
    Settings o; std::map<std::string, std::string> kv; std::stringstream ss(s); std::string it;
    while (std::getline(ss, it, ';')) { auto p = it.find('='); if (p != std::string::npos) kv[it.substr(0, p)] = it.substr(p + 1); }
    auto num = [&](const char* k, int d) { auto f = kv.find(k); return f == kv.end() ? d : atoi(f->second.c_str()); };
    auto real = [&](const char* k, float d) { auto f = kv.find(k); return f == kv.end() ? d : (float)atof(f->second.c_str()); };
    o.res = std::clamp(real("res", 1.0f), 0.10f, 1.0f); o.fps = num("fps", 60); o.vsync = num("vsync", 1); o.shaders = num("shaders", 1);
    o.audio = num("audio", 1); o.hud = num("hud", 1);
    if (kv.count("lang")) o.lang = kv["lang"];
    return o;
}

InputState g_in;
std::mutex g_winMu, g_statMu;
ANativeWindow* g_win = nullptr;
std::thread g_thread;
std::atomic<bool> g_run{false}, g_paused{false};
std::string g_status = "Parado.";

void SetStatus(const std::string& s) { std::lock_guard<std::mutex> l(g_statMu); g_status = s; }

// ---------- vídeo: framebuffer de diagnóstico (até o backend Latte->Vulkan existir) ----------
struct Canvas {
    uint32_t* px; int stride;
    void Rect(int x, int y, int w, int h, uint32_t c) {
        for (int j = std::max(0, y); j < std::min(H, y + h); ++j)
            for (int i = std::max(0, x); i < std::min(W, x + w); ++i) px[j * stride + i] = c;
    }
    void Disc(int cx, int cy, int r, int ring, uint32_t c) {
        for (int j = cy - r; j <= cy + r; ++j) for (int i = cx - r; i <= cx + r; ++i) {
            if (i < 0 || j < 0 || i >= W || j >= H) continue;
            int d2 = (i - cx) * (i - cx) + (j - cy) * (j - cy);
            if (d2 <= r * r && (ring == 0 || d2 >= (r - ring) * (r - ring))) px[j * stride + i] = c;
        }
    }
};
constexpr uint32_t RGBA(int r, int g, int b) { return 0xFF000000u | (uint32_t)b << 16 | (uint32_t)g << 8 | (uint32_t)r; }

void Present(uint64_t frame, int state, const Settings& st) {
    std::lock_guard<std::mutex> l(g_winMu);
    if (!g_win) return;
    ANativeWindow_setBuffersGeometry(g_win, W, H, WINDOW_FORMAT_RGBA_8888);
    ANativeWindow_Buffer buf;
    if (ANativeWindow_lock(g_win, &buf, nullptr) != 0) return;
    Canvas c{static_cast<uint32_t*>(buf.bits), buf.stride};
    c.Rect(0, 0, W, H, RGBA(20, 23, 29));
    if (st.hud) {
        uint32_t sc = state == 1 ? RGBA(60, 200, 110) : state == 2 ? RGBA(240, 170, 40) : state == 3 ? RGBA(230, 70, 70) : RGBA(120, 120, 130);
        c.Rect(0, 0, W, 6, sc);
        uint32_t b = g_in.buttons.load();
        for (int k = 0; k < kButtonCount; ++k)
            c.Rect(20 + k * 48, 40, 40, 40, (b >> k) & 1 ? RGBA(45, 140, 255) : RGBA(44, 49, 60));
        auto stick = [&](int cx, float x, float y) {
            c.Disc(cx, 300, 80, 3, RGBA(70, 78, 94));
            c.Disc(cx + (int)(x * 60), 300 - (int)(y * 60), 18, 0, RGBA(45, 140, 255));
        };
        stick(200, g_in.lx, g_in.ly); stick(654, g_in.rx, g_in.ry);
        if (g_in.touch) c.Disc((int)(g_in.tx * W), (int)(g_in.ty * H), 14, 0, RGBA(255, 120, 60));
        float g[3] = {g_in.gx, g_in.gy, g_in.gz};
        for (int k = 0; k < 3; ++k) {
            c.Rect(377, 150 + k * 24, 100, 12, RGBA(44, 49, 60));
            int w = (int)std::fmin(50.f, std::fabs(g[k]) * 20.f);
            c.Rect(427 + (g[k] < 0 ? -w : 0), 150 + k * 24, w, 12, RGBA(240, 170, 40));
        }
        c.Rect((int)(frame % (W - 40)), H - 14, 40, 8, RGBA(60, 200, 110));
    }
    ANativeWindow_unlockAndPost(g_win);
}

// ---------- núcleo ----------
void Loop(std::vector<uint8_t> image, Settings st, std::string name) {
    Memory mem; Cpu cpu(&mem);
    LoadResult lr = LoadRpx(image.data(), image.size(), mem);
    image.clear(); image.shrink_to_fit();
    std::string info;
    if (lr.ok) {
        mem.Map(0x0F000000, 0x100000);
        cpu.pc = lr.entry; cpu.gpr[1] = 0x0F0FFF00;
        info = name + ": " + lr.msg + " (" + std::to_string(lr.sections) + " seções, " + std::to_string(lr.importSections) + " de imports)";
    } else {
        cpu.halted = true; cpu.haltReason = lr.msg; info = name + ": " + lr.msg;
    }
    uint64_t frame = 0, lastExec = 0;
    auto t0 = std::chrono::steady_clock::now(), tMips = t0;
    double mips = 0;
    while (g_run) {
        auto fs = std::chrono::steady_clock::now();
        bool paused = g_paused;
        if (!paused && !cpu.halted) cpu.Run(200000);
        int state = paused ? 2 : cpu.halted ? 3 : 1;
        Present(frame++, state, st);
        auto now = std::chrono::steady_clock::now();
        double dt = std::chrono::duration<double>(now - tMips).count();
        if (dt >= 1.0) { mips = (cpu.executed - lastExec) / dt / 1e6; lastExec = cpu.executed; tMips = now; }
        std::ostringstream o;
        o << info << "\nCPU: " << (paused ? "pausada" : cpu.halted ? "parada: " + cpu.haltReason : "rodando")
          << " | " << (int)(mips * 10) / 10.0 << " MIPS | instruções: " << cpu.executed << " | quadros: " << frame;
        SetStatus(o.str());
        if (st.fps > 0) {
            auto target = fs + std::chrono::microseconds(1000000 / st.fps);
            std::this_thread::sleep_until(target);
        } else std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}
}  // namespace

std::string LoadTitle(const std::string&) { return "Use Start() com um descritor de arquivo."; }

std::string Start(int fd, const std::string& ext, const std::string& name, const std::string& settings) {
    Stop();
    if (ext == "wua" || ext == "wud" || ext == "wux" || ext == "iso" || ext == "wuhb") {
        if (fd >= 0) close(fd);
        return "ERRO: formato ." + ext + " ainda não é suportado (exige descriptografia/descompressão). Use a pasta do jogo (code/content/meta) com .rpx.";
    }
    if (fd < 0) return "ERRO: não foi possível abrir o arquivo do jogo.";
    std::vector<uint8_t> data; uint8_t tmp[1 << 16]; ssize_t n;
    while ((n = read(fd, tmp, sizeof tmp)) > 0) {
        data.insert(data.end(), tmp, tmp + n);
        if (data.size() > (768u << 20)) { close(fd); return "ERRO: arquivo grande demais."; }
    }
    close(fd);
    if (data.empty()) return "ERRO: arquivo vazio.";
    g_paused = false; g_run = true;
    g_thread = std::thread(Loop, std::move(data), ParseSettings(settings), name);
    LOGI("núcleo iniciado: %s", name.c_str());
    return "OK: núcleo iniciado.";
}

void Pause(bool p) { g_paused = p; }
void Stop() {
    g_run = false;
    if (g_thread.joinable()) g_thread.join();
    SetStatus("Parado.");
}
void SetWindow(ANativeWindow* w) {
    std::lock_guard<std::mutex> l(g_winMu);
    if (g_win) ANativeWindow_release(g_win);
    g_win = w;
}
void SetInput(uint32_t b, float lx, float ly, float rx, float ry) {
    g_in.buttons = b; g_in.lx = lx; g_in.ly = ly; g_in.rx = rx; g_in.ry = ry;
}
void SetTouch(bool d, float x, float y) { g_in.touch = d; g_in.tx = x; g_in.ty = y; }
void SetGyro(float x, float y, float z) { g_in.gx = x; g_in.gy = y; g_in.gz = z; }
std::string Status() { std::lock_guard<std::mutex> l(g_statMu); return g_status; }
}  // namespace core
