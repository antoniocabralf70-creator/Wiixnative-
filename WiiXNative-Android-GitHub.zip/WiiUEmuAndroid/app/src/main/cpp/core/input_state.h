#pragma once
#include <atomic>
#include <cstdint>

namespace core {
// Máscara de botões do GamePad. O mesmo contrato existe em Controls.kt (object Btn).
enum Button : uint32_t {
    kA = 1u << 0, kB = 1u << 1, kX = 1u << 2, kY = 1u << 3,
    kL = 1u << 4, kR = 1u << 5, kZL = 1u << 6, kZR = 1u << 7,
    kPlus = 1u << 8, kMinus = 1u << 9, kHome = 1u << 10,
    kUp = 1u << 11, kDown = 1u << 12, kLeft = 1u << 13, kRight = 1u << 14,
    kL3 = 1u << 15, kR3 = 1u << 16,
};
constexpr int kButtonCount = 17;

struct InputState {
    std::atomic<uint32_t> buttons{0};
    std::atomic<float> lx{0}, ly{0}, rx{0}, ry{0};
    std::atomic<bool> touch{false};
    std::atomic<float> tx{0}, ty{0};
    std::atomic<float> gx{0}, gy{0}, gz{0};
};
}  // namespace core
