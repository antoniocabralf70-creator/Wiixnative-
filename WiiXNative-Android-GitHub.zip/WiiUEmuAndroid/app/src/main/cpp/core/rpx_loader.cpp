#include "core/rpx_loader.h"
#include <zlib.h>
#include <vector>

namespace core {
namespace {
uint32_t BE32(const uint8_t* p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }
uint32_t BE16(const uint8_t* p) { return (uint32_t)p[0] << 8 | p[1]; }
constexpr uint32_t SHF_ALLOC = 2, SHF_ZLIB = 0x08000000, SHT_NOBITS = 8, SHT_IMPORTS = 0x80000002;
}  // namespace

LoadResult LoadRpx(const uint8_t* d, size_t n, Memory& mem) {
    LoadResult r;
    if (n < 52 || d[0] != 0x7F || d[1] != 'E' || d[2] != 'L' || d[3] != 'F') { r.msg = "arquivo não é ELF/RPX (talvez esteja criptografado)"; return r; }
    if (d[4] != 1 || d[5] != 2 || BE16(d + 18) != 20) { r.msg = "ELF não é PowerPC 32-bit big-endian"; return r; }
    r.entry = BE32(d + 24);
    uint32_t shoff = BE32(d + 32), shentsize = BE16(d + 46), shnum = BE16(d + 48);
    if (shentsize < 40 || (uint64_t)shoff + (uint64_t)shnum * shentsize > n) { r.msg = "tabela de seções inválida"; return r; }
    for (uint32_t s = 0; s < shnum; ++s) {
        const uint8_t* h = d + shoff + s * shentsize;
        uint32_t type = BE32(h + 4), flags = BE32(h + 8), addr = BE32(h + 12), off = BE32(h + 16), size = BE32(h + 20);
        if (type == SHT_IMPORTS) r.importSections++;
        if (!(flags & SHF_ALLOC) || addr == 0 || size == 0) continue;
        if (size > (512u << 20)) { r.msg = "seção grande demais"; return r; }
        if (type == SHT_NOBITS) { mem.Map(addr, size); r.sections++; continue; }
        if ((uint64_t)off + size > n) { r.msg = "seção fora do arquivo"; return r; }
        const uint8_t* src = d + off;
        std::vector<uint8_t> out;
        if (flags & SHF_ZLIB) {
            if (size < 5) { r.msg = "seção zlib truncada"; return r; }
            uLongf outLen = BE32(src);
            if (outLen > (512u << 20)) { r.msg = "seção descomprimida grande demais"; return r; }
            out.resize(outLen);
            if (uncompress(out.data(), &outLen, src + 4, size - 4) != Z_OK) { r.msg = "falha ao descomprimir seção"; return r; }
            out.resize(outLen);
            src = out.data(); size = (uint32_t)outLen;
        }
        mem.Map(addr, size);
        if (!mem.Write(addr, src, size)) { r.msg = "falha ao copiar seção"; return r; }
        r.bytes += size; r.sections++;
    }
    r.ok = true;
    r.msg = "RPX carregado";
    return r;
}
}  // namespace core
