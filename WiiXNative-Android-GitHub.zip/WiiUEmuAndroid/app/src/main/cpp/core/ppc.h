#pragma once
#include <map>
#include <string>
#include "core/memory.h"

namespace core {

// Interpretador PowerPC (Espresso). Cobre inteiros, desvios, load/store e a
// maior parte do que aparece em prólogos/epílogos. Ponto flutuante, paired
// singles e syscalls (Cafe OS) ainda param a CPU com uma mensagem clara.
class Cpu {
public:
    explicit Cpu(Memory* m) : mem(m) {}
    void Run(uint64_t maxInstr);
    bool Step();

    uint32_t gpr[32] = {};
    uint32_t pc = 0, lr = 0, ctr = 0, cr = 0, xer = 0, msr = 0;
    std::map<uint32_t, uint32_t> sprs;
    Memory* mem;
    bool halted = false;
    std::string haltReason;
    uint64_t executed = 0;

private:
    void Halt(const std::string& why);
    void SetCR0(int32_t v);
    void SetCRF(int f, int32_t a, int32_t b);
    void SetCRFU(int f, uint32_t a, uint32_t b);
    bool CrBit(int bi) const { return (cr >> (31 - bi)) & 1; }
};

}  // namespace core
