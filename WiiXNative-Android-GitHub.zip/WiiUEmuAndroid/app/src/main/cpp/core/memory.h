#pragma once
#include <cstdint>
#include <cstring>
#include <memory>
#include <vector>

namespace core {

// Memória paginada (4 KB) de 32 bits, big-endian, alocada sob demanda.
class Memory {
public:
    Memory() : pages_(1u << 20) {}

    void Map(uint32_t addr, uint32_t size) {
        uint64_t end = (uint64_t)addr + size;
        for (uint64_t p = addr >> 12; p < ((end + 0xFFF) >> 12); ++p)
            if (!pages_[p]) pages_[p].reset(new uint8_t[4096]());
    }
    bool Write(uint32_t addr, const void* src, size_t n) {
        auto* s = static_cast<const uint8_t*>(src);
        for (size_t i = 0; i < n; ++i) { uint8_t* d = Ptr(addr + (uint32_t)i); if (!d) return false; *d = s[i]; }
        return true;
    }
    bool Read8(uint32_t a, uint32_t& v)  { uint8_t* p = Ptr(a); if (!p) return false; v = *p; return true; }
    bool Read16(uint32_t a, uint32_t& v) { return ReadN(a, 2, v); }
    bool Read32(uint32_t a, uint32_t& v) { return ReadN(a, 4, v); }
    bool Write8(uint32_t a, uint32_t v)  { uint8_t* p = Ptr(a); if (!p) return false; *p = (uint8_t)v; return true; }
    bool Write16(uint32_t a, uint32_t v) { return WriteN(a, 2, v); }
    bool Write32(uint32_t a, uint32_t v) { return WriteN(a, 4, v); }
    uint8_t* Ptr(uint32_t a) { auto& p = pages_[a >> 12]; return p ? p.get() + (a & 0xFFF) : nullptr; }

private:
    bool ReadN(uint32_t a, int n, uint32_t& v) {
        v = 0;
        for (int i = 0; i < n; ++i) { uint8_t* p = Ptr(a + i); if (!p) return false; v = (v << 8) | *p; }
        return true;
    }
    bool WriteN(uint32_t a, int n, uint32_t v) {
        for (int i = n - 1; i >= 0; --i) { uint8_t* p = Ptr(a + i); if (!p) return false; *p = (uint8_t)v; v >>= 8; }
        return true;
    }
    std::vector<std::unique_ptr<uint8_t[]>> pages_;
};

}  // namespace core
