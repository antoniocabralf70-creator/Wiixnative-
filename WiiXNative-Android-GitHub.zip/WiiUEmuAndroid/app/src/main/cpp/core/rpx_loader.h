#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include "core/memory.h"

namespace core {
struct LoadResult {
    bool ok = false;
    std::string msg;
    uint32_t entry = 0;
    int sections = 0;
    int importSections = 0;
    uint64_t bytes = 0;
};
// Carrega um RPX/RPL (ELF PowerPC big-endian com seções zlib) na memória emulada.
LoadResult LoadRpx(const uint8_t* data, size_t size, Memory& mem);
}  // namespace core
